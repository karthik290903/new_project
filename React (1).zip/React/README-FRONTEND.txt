VBI FINANCE AI — FRONTEND UPDATE (React + Vite + TypeScript)

WHAT THIS ZIP CONTAINS
- Existing Finance Assistant UI and finance chat API integration retained.
- Visualization Studio page added and connected to POST /api/visualizations.
- Bar, line and donut chart rendering via Recharts.
- Stacked chart selector included, with a note that true multi-scenario stacking needs a multi-scenario backend response.
- Vodafone-inspired enterprise styling: Vodafone red (#E60000), aubergine, neutral greys, clean typography.
- Fixed viewport shell: page-level scrolling disabled; conversation and visualization workspaces scroll internally when needed.
- Vodafone logo is referenced from Wikimedia Commons (requires network access). It is the Vodafone Group logo, not the Vodafone Idea / Vi logo.

INSTALL / RUN
1. Copy the contents of this frontend folder into your existing project frontend folder, allowing the files to replace the matching frontend files.
2. From the frontend folder run: npm install
3. Start the frontend using: npm run dev
4. Keep your existing FastAPI backend running on port 8000.

IMPORTANT BACKEND REQUIREMENT
The frontend expects POST /api/visualizations to be available. This is the separate endpoint added in the backend steps. Existing POST /api/chat is retained and unchanged.

FILES TO CREATE / REPLACE
Create if missing:
- frontend/index.html
- frontend/package.json
- frontend/tsconfig.json
- frontend/src/vite-env.d.ts
- frontend/src/types/visualization.ts
- frontend/src/components/VisualizationBuilder.tsx
- frontend/src/styles/visualization.css

Replace/update:
- frontend/src/App.tsx
- frontend/src/App.css
- frontend/src/components/Sidebar.tsx
- frontend/src/services/api.ts

Keep as-is (unless your local version differs):
- frontend/src/main.tsx
- frontend/src/index.css
- frontend/src/components/FinanceResponse.tsx
- frontend/src/types/finance.ts
- frontend/vite.config.ts
- frontend/.env.example

LOGO SOURCE
Vodafone Group logo SVG: https://upload.wikimedia.org/wikipedia/commons/e/ef/Vodafone_Logo.svg
Source page: https://commons.wikimedia.org/wiki/File:Vodafone_Logo.svg
The logo is loaded remotely by Sidebar.tsx. For an offline or restricted corporate environment, obtain the approved Vodafone logo asset from your organisation's brand/media library and place it at frontend/public/vodafone-logo.svg; then change the Sidebar image src to /vodafone-logo.svg.

DESIGN / VIEWPORT NOTES
The app shell uses 100dvh and overflow hidden to prevent page-level scrolling. Long conversation content scrolls inside its own panel; the Visualization Studio has its own scroll area on smaller screens. On very short displays, internal workspace scrolling is intentional so controls remain reachable.

LIMITATION
The current visualization backend service accepts one scenario per request. Therefore the Stacked option currently renders the selected scenario as a bar chart and displays an explanatory note. Do not use it for actual stacked scenario comparisons until the backend supports multiple scenarios and returns one value series per scenario.
