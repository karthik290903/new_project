import { useState } from "react";
import { ResponsiveContainer, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { generateVisualization } from "../services/api";
import type { VisualizationMetric, VisualizationScenario, VisualizationDimension, VisualizationResponse } from "../types/visualization";
import "../styles/visualization.css";

type ChartType = "bar" | "line" | "donut" | "stacked";
const COLORS = ["#e60000", "#9c2aa0", "#00b0ca", "#a8b400", "#eb9700", "#5e2750"];

export default function VisualizationBuilder() {
  const [metric, setMetric] = useState<VisualizationMetric>("total_revenue");
  const [scenario, setScenario] = useState<VisualizationScenario>("ACT");
  const [dimension, setDimension] = useState<VisualizationDimension>("region");
  const [chartType, setChartType] = useState<ChartType>("bar");
  const [period, setPeriod] = useState("");
  const [segment, setSegment] = useState("");
  const [region, setRegion] = useState("");
  const [result, setResult] = useState<VisualizationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setLoading(true); setError("");
    try {
      const filters: NonNullable<Parameters<typeof generateVisualization>[0]["filters"]> = {};
      if (period.trim()) filters.financial_period = period.trim();
      if (segment) filters.segment = segment;
      if (region) filters.region = region;
      setResult(await generateVisualization({ metric, scenario, dimension, filters }));
    } catch (e) { setError(e instanceof Error ? e.message : "Unable to generate chart."); }
    finally { setLoading(false); }
  }

  function reset() {
    setMetric("total_revenue"); setScenario("ACT"); setDimension("region"); setChartType("bar");
    setPeriod(""); setSegment(""); setRegion(""); setResult(null); setError("");
  }

  function renderChart() {
    if (!result?.data.length) return <div className="viz-empty">No data returned for these selections.</div>;
    if (chartType === "donut") return <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={result.data} dataKey="value" nameKey="category" cx="50%" cy="50%" innerRadius="52%" outerRadius="78%" paddingAngle={3}>{result.data.map((d, i) => <Cell key={`${d.category}-${i}`} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer>;
    if (chartType === "line") return <ResponsiveContainer width="100%" height="100%"><LineChart data={result.data} margin={{ top: 12, right: 20, left: 4, bottom: 8 }}><CartesianGrid strokeDasharray="3 3" stroke="#e7e7e9" /><XAxis dataKey="category" tick={{ fill: "#68686d", fontSize: 11 }} /><YAxis tick={{ fill: "#68686d", fontSize: 11 }} /><Tooltip /><Legend /><Line type="monotone" dataKey="value" name={result.metric_label} stroke="#e60000" strokeWidth={3} dot={{ r: 4 }} /></LineChart></ResponsiveContainer>;
    return <ResponsiveContainer width="100%" height="100%"><BarChart data={result.data} margin={{ top: 12, right: 20, left: 4, bottom: 8 }}><CartesianGrid strokeDasharray="3 3" stroke="#e7e7e9" /><XAxis dataKey="category" tick={{ fill: "#68686d", fontSize: 11 }} /><YAxis tick={{ fill: "#68686d", fontSize: 11 }} /><Tooltip /><Legend /><Bar dataKey="value" name={result.metric_label} fill="#e60000" radius={[5, 5, 0, 0]} /></BarChart></ResponsiveContainer>;
  }

  return <div className="viz-workspace">
    <div className="viz-heading"><div><span className="viz-kicker">FINANCE INTELLIGENCE / SELF-SERVE</span><h2>Visualization Studio</h2><p>Build a chart from governed finance data in BigQuery.</p></div><span className="viz-live"><i /> DATA CONNECTED</span></div>
    <div className="viz-grid">
      <aside className="viz-config">
        <div className="viz-section-title"><span>01</span><h3>Configure your chart</h3></div>
        <label>Measure</label><select value={metric} onChange={e => setMetric(e.target.value as VisualizationMetric)}><option value="service_revenue">Service Revenue</option><option value="non_service_revenue">Non-Service Revenue</option><option value="total_revenue">Total Revenue</option><option value="cost_of_sales">Cost of Sales</option></select>
        <label>Scenario</label><select value={scenario} onChange={e => setScenario(e.target.value as VisualizationScenario)}><option value="ACT">Actuals</option><option value="DB">Budget</option><option value="QRF">QRF Forecast</option></select>
        <label>Group by</label><select value={dimension} onChange={e => setDimension(e.target.value as VisualizationDimension)}><option value="region">Region</option><option value="segment">Segment</option><option value="country">Country</option><option value="product">Product</option><option value="financial_period">Financial Period</option></select>
        <label>Chart style</label><div className="viz-chart-types">{(["bar", "line", "donut", "stacked"] as ChartType[]).map(t => <button key={t} className={chartType === t ? "selected" : ""} onClick={() => setChartType(t)}>{t === "bar" ? "▥ Bar" : t === "line" ? "⌁ Line" : t === "donut" ? "◉ Donut" : "▤ Stacked"}</button>)}</div>
        <div className="viz-rule" /><div className="viz-section-title"><span>02</span><h3>Apply filters</h3></div>
        <label>Financial period</label><input value={period} onChange={e => setPeriod(e.target.value)} placeholder="e.g. 001.2026" />
        <label>Segment</label><select value={segment} onChange={e => setSegment(e.target.value)}><option value="">All segments</option><option>Fixed</option><option>IoT</option><option>Mobility</option></select>
        <label>Region</label><select value={region} onChange={e => setRegion(e.target.value)}><option value="">All regions</option><option>Asia</option><option>Americas</option><option>Europe</option><option>Others</option></select>
        <div className="viz-actions"><button className="viz-generate" onClick={() => void generate()} disabled={loading}>{loading ? "Generating…" : "Generate chart  →"}</button><button className="viz-reset" onClick={reset}>Reset</button></div>
      </aside>
      <section className="viz-result"><div className="viz-result-head"><div><span className="viz-kicker">OUTPUT CANVAS</span><h3>{result ? `${result.metric_label} by ${result.dimension.split("_").join(" ")}` : "Chart preview"}</h3><p>{result ? `${result.scenario_label} · ${result.total_rows} categories` : "Your generated visualization will appear here."}</p></div>{result && <span className="viz-scenario-pill">{result.scenario_label}</span>}</div>
        {error && <div className="viz-error">{error}</div>}
        {result ? <><div className="viz-chart-canvas">{renderChart()}</div><div className="viz-result-foot"><span>Source: BigQuery · unioned_financial</span><span>Query ID: {result.job_id}</span></div></> : <div className="viz-placeholder"><div className="viz-placeholder-mark">V</div><h3>Turn finance data into insight</h3><p>Choose a measure, scenario and grouping dimension, then generate your chart.</p></div>}
        {chartType === "stacked" && <p className="viz-note">Stacked scenario comparison requires the multi-scenario API extension. This preview currently uses the selected scenario only.</p>}
      </section>
    </div>
  </div>;
}
