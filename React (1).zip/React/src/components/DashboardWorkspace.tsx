import { useEffect, useMemo, useState } from "react";

import {
  getDashboardCatalog,
  getDashboardChartData,
  getFilterValues,
  type DashboardCatalog,
  type DashboardChartData,
} from "../services/dashboardApi";

import {
  saveReport,
  updateSavedReport,
} from "../services/reportsApi";

type ChartType = "kpi" | "table" | "bar" | "line" | "donut" | "stacked";

interface SavedChartDefinition {
  id?: string;
  chart_id?: string;
  title?: string;
  chart_type?: string;
  type?: string;
  dimension?: string;
  measure?: string;
  scenario?: string;
}

interface SavedSheetDefinition {
  id?: string;
  name?: string;
  charts?: SavedChartDefinition[];
}

interface SavedReportInput {
  report_id: string;
  report_name: string;
  definition?: {
    charts?: SavedChartDefinition[];
    sheets?: SavedSheetDefinition[];
    filters?: Record<string, string | string[]>;
  };
}

interface DashboardWorkspaceProps {
  savedReport?: SavedReportInput | null;
  onSaved?: () => void;
}

interface DashboardChart {
  id: string;
  title: string;
  type: ChartType;
  dimension: string;
  measure: string;
  scenario: string;
}

interface DashboardFilter {
  id: string;
  column: string;
  values: string[];
}

interface DashboardSheet {
  id: string;
  name: string;
}

const chartLibrary: {
  type: ChartType;
  label: string;
  description: string;
  icon: string;
}[] = [
  {
    type: "kpi",
    label: "KPI Card",
    description: "Highlight a key financial measure",
    icon: "▣",
  },
  {
    type: "table",
    label: "Table",
    description: "Show detailed financial records",
    icon: "▤",
  },
  {
    type: "bar",
    label: "Bar Chart",
    description: "Compare financial categories",
    icon: "▥",
  },
  {
    type: "line",
    label: "Line Chart",
    description: "Track performance over time",
    icon: "⌁",
  },
  {
    type: "donut",
    label: "Donut Chart",
    description: "Show category contribution",
    icon: "◉",
  },
  {
    type: "stacked",
    label: "Stacked Bar",
    description: "Compare multiple series",
    icon: "▥",
  },
];

const filterColumns = [
  { value: "region", label: "Region" },
  { value: "segment", label: "Segment" },
  { value: "financial_period", label: "Financial Period" },
  { value: "country", label: "Country" },
  { value: "product", label: "Product" },
  { value: "customer_name", label: "Customer" },
  { value: "customer_id", label: "Customer ID" },
  { value: "hyper_cat", label: "Hyper Category" },
  { value: "gan", label: "GAN" },
];

const fallbackCatalog: DashboardCatalog = {
  dimensions: [
    { value: "region", label: "Region" },
    { value: "segment", label: "Segment" },
    { value: "financial_period", label: "Financial Period" },
    { value: "country", label: "Country" },
    { value: "product", label: "Product" },
    { value: "customer_name", label: "Customer" },
    { value: "hyper_cat", label: "Hyper Category" },
  ],
  measures: [
    { value: "TOTAL_REVENUE", label: "Total Revenue" },
    { value: "SERVICE_REVENUE", label: "Service Revenue" },
    { value: "NON_SERVICE_REVENUE", label: "Non-Service Revenue" },
    { value: "COST_OF_SALES", label: "Cost of Sales" },
  ],
  scenarios: [
    { value: "ACT", label: "Actuals" },
    { value: "DB", label: "Budget" },
    { value: "QRF", label: "QRF Forecast" },
  ],
};

function createChart(type: ChartType): DashboardChart {
  const definition = chartLibrary.find((item) => item.type === type);

  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: definition?.label ?? "New Chart",
    type,
    dimension: "region",
    measure: "TOTAL_REVENUE",
    scenario: "ACT",
  };
}

function restoreChart(
  item: SavedChartDefinition,
  index: number,
  reportId: string,
): DashboardChart {
  const rawType = item.chart_type ?? item.type ?? "bar";

  const validType: ChartType = chartLibrary.some(
    (chartType) => chartType.type === rawType,
  )
    ? (rawType as ChartType)
    : "bar";

  return {
    id: item.id ?? item.chart_id ?? `restored-${reportId}-${index}`,
    title:
      item.title ??
      chartLibrary.find((entry) => entry.type === validType)?.label ??
      "Saved chart",
    type: validType,
    dimension: item.dimension ?? "region",
    measure: item.measure ?? "TOTAL_REVENUE",
    scenario: item.scenario ?? "ACT",
  };
}

function numericValue(value: unknown): number {
  if (value === null || value === undefined || value === "") return 0;

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatValue(value: number): string {
  return new Intl.NumberFormat("en-GB", {
    notation: "compact",
    maximumFractionDigits: 2,
  }).format(value);
}

function ChartPreview({
  chart,
  data,
  loading,
  error,
}: {
  chart: DashboardChart;
  data?: DashboardChartData;
  loading: boolean;
  error?: string;
}) {
  const rows = data?.rows ?? [];
  const points = rows.map((row) => ({
    label: String(row.dimension_value ?? "Unassigned"),
    value: numericValue(row.metric_value),
  }));

  const total = points.reduce((sum, point) => sum + point.value, 0);
  const maxValue = Math.max(
    ...points.map((point) => Math.abs(point.value)),
    0,
  );

  if (loading) {
    return <div className="vf-data-state">Loading BigQuery data…</div>;
  }

  if (error) {
    return (
      <div className="vf-data-error">
        Unable to load chart data: {error}
      </div>
    );
  }

  if (!points.length) {
    return (
      <div className="vf-data-state">
        No data available for this selection.
      </div>
    );
  }

  if (chart.type === "kpi") {
    return (
      <div className="vf-kpi-preview">
        <span className="vf-small-label">
          {chart.measure.replace("_", " ")}
        </span>
        <strong>{formatValue(total)}</strong>
        <span className="vf-data-caption">
          {data?.total_rows ?? points.length} grouped records · {chart.scenario}
        </span>
        <div className="vf-mini-bars">
          {points.slice(0, 12).map((point, index) => (
            <i
              key={`${point.label}-${index}`}
              style={{
                height: `${Math.max(
                  5,
                  maxValue ? (Math.abs(point.value) / maxValue) * 100 : 5,
                )}%`,
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (chart.type === "table") {
    return (
      <div className="vf-table">
        <div className="vf-table-row vf-table-head">
          <span>{chart.dimension.replace("_", " ")}</span>
          <span>{chart.measure.replace("_", " ")}</span>
        </div>
        {points.map((point, index) => (
          <div className="vf-table-row" key={`${point.label}-${index}`}>
            <span>{point.label}</span>
            <strong>{formatValue(point.value)}</strong>
          </div>
        ))}
      </div>
    );
  }

  if (chart.type === "donut") {
    let running = 0;
    const palette = [
      "#E60000",
      "#ef7777",
      "#a94b4b",
      "#bcbcbc",
      "#777777",
      "#f3aaaa",
    ];

    const absoluteTotal = points.reduce(
      (sum, point) => sum + Math.abs(point.value),
      0,
    );

    const segments = points.map((point, index) => {
      const start = running;
      running += absoluteTotal
        ? (Math.abs(point.value) / absoluteTotal) * 100
        : 0;

      return `${palette[index % palette.length]} ${start}% ${running}%`;
    });

    return (
      <div className="vf-donut-layout">
        <div
          className="vf-donut"
          style={{ background: `conic-gradient(${segments.join(", ")})` }}
        >
          <div className="vf-donut-hole">
            <strong>{formatValue(total)}</strong>
            <span>Total</span>
          </div>
        </div>
        <div className="vf-legend">
          {points.slice(0, 7).map((point, index) => (
            <div key={`${point.label}-${index}`}>
              <i
                className="vf-dot"
                style={{ background: palette[index % palette.length] }}
              />
              <span>{point.label}</span>
              <strong>
                {absoluteTotal
                  ? `${(
                      (Math.abs(point.value) / absoluteTotal) *
                      100
                    ).toFixed(1)}%`
                  : "0%"}
              </strong>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (chart.type === "line") {
    const width = 520;
    const height = 150;
    const min = Math.min(...points.map((point) => point.value), 0);
    const range = maxValue - min || 1;

    const coordinates = points.map((point, index) => {
      const x =
        points.length === 1
          ? width / 2
          : (index / (points.length - 1)) * width;
      const y =
        height -
        ((point.value - min) / range) * (height - 20) -
        10;

      return `${x},${y}`;
    });

    return (
      <div className="vf-line-preview">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="none"
          role="img"
          aria-label={`${chart.title} line chart`}
        >
          {[25, 60, 95, 130].map((y) => (
            <line
              key={y}
              x1="0"
              y1={y}
              x2={width}
              y2={y}
              stroke="#dedede"
              strokeDasharray="4 5"
            />
          ))}
          <polyline
            points={coordinates.join(" ")}
            fill="none"
            stroke="#E60000"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <div className="vf-axis-labels">
          {points
            .filter(
              (_, index) =>
                index % Math.max(1, Math.ceil(points.length / 6)) === 0,
            )
            .map((point, index) => (
              <span key={`${point.label}-${index}`}>{point.label}</span>
            ))}
        </div>
      </div>
    );
  }

  return (
    <div className="vf-bar-preview">
      {points.map((point, index) => (
        <div className="vf-bar-row" key={`${point.label}-${index}`}>
          <span title={point.label}>{point.label}</span>
          <div className="vf-bar-track">
            <i
              style={{
                width: `${
                  maxValue ? (Math.abs(point.value) / maxValue) * 100 : 0
                }%`,
              }}
            />
          </div>
          <strong>{formatValue(point.value)}</strong>
        </div>
      ))}
    </div>
  );
}

export default function DashboardWorkspace({
  savedReport = null,
  onSaved,
}: DashboardWorkspaceProps) {
  const [dashboardName, setDashboardName] = useState(
    "Finance Performance Dashboard",
  );
  const [restoredReportId, setRestoredReportId] = useState<string | null>(null);
  const [filters, setFilters] = useState<DashboardFilter[]>([]);
  const [selectedFilterId, setSelectedFilterId] = useState<string | null>(null);
  const [filterOptions, setFilterOptions] = useState<
    Record<string, string[]>
  >({});
  const [filterOptionsLoading, setFilterOptionsLoading] = useState<
    Record<string, boolean>
  >({});
  const [filterOptionsError, setFilterOptionsError] = useState<
    Record<string, string>
  >({});
  const [saving, setSaving] = useState(false);

  const [sheets, setSheets] = useState<DashboardSheet[]>([
    { id: "sheet-1", name: "Dashboard 1" },
  ]);
  const [activeSheetId, setActiveSheetId] = useState("sheet-1");
  const [editingSheetId, setEditingSheetId] = useState<string | null>(null);
  const [chartsBySheet, setChartsBySheet] = useState<
    Record<string, DashboardChart[]>
  >(() => ({
    "sheet-1": [
      { ...createChart("kpi"), title: "Total Revenue" },
      { ...createChart("bar"), title: "Revenue by Region" },
      { ...createChart("line"), title: "Revenue Trend" },
    ],
  }));

  const charts = chartsBySheet[activeSheetId] ?? [];

  function setCharts(
    update:
      | DashboardChart[]
      | ((current: DashboardChart[]) => DashboardChart[]),
  ) {
    setChartsBySheet((current) => {
      const currentCharts = current[activeSheetId] ?? [];
      return {
        ...current,
        [activeSheetId]:
          typeof update === "function" ? update(currentCharts) : update,
      };
    });
  }

  const [selectedChartId, setSelectedChartId] = useState<string | null>(null);
  const [showLibrary, setShowLibrary] = useState(true);
  const [showSettings, setShowSettings] = useState(true);
  const [draggedChartId, setDraggedChartId] = useState<string | null>(null);

  const [catalog, setCatalog] = useState<DashboardCatalog>(fallbackCatalog);
  const [catalogError, setCatalogError] = useState("");
  const [chartData, setChartData] = useState<
    Record<string, DashboardChartData>
  >({});
  const [chartLoading, setChartLoading] = useState<Record<string, boolean>>({});
  const [chartErrors, setChartErrors] = useState<Record<string, string>>({});

  function updateFilter(
    filterId: string,
    update: Partial<DashboardFilter>,
  ) {
    setFilters((current) =>
      current.map((filter) =>
        filter.id === filterId ? { ...filter, ...update } : filter,
      ),
    );
  }

  async function loadFilterOptions(filterId: string, column: string) {
    setFilterOptions((current) => ({ ...current, [filterId]: [] }));
    setFilterOptionsError((current) => ({ ...current, [filterId]: "" }));

    if (!column) {
      setFilterOptionsLoading((current) => ({
        ...current,
        [filterId]: false,
      }));
      return;
    }

    setFilterOptionsLoading((current) => ({
      ...current,
      [filterId]: true,
    }));

    try {
      const response = await getFilterValues(column);
      setFilterOptions((current) => ({
        ...current,
        [filterId]: response.values ?? [],
      }));
    } catch (error) {
      setFilterOptionsError((current) => ({
        ...current,
        [filterId]:
          error instanceof Error
            ? error.message
            : "Unable to load filter values",
      }));
    } finally {
      setFilterOptionsLoading((current) => ({
        ...current,
        [filterId]: false,
      }));
    }
  }

  function handleFilterColumnChange(filterId: string, column: string) {
    updateFilter(filterId, { column, values: [] });
    void loadFilterOptions(filterId, column);
  }

  // Restore either the newer multi-sheet format or older flat-chart reports.
  useEffect(() => {
    if (!savedReport?.definition) return;

    let cancelled = false;
    const definition = savedReport.definition;
    let restoredSheets: DashboardSheet[];
    let restoredChartsBySheet: Record<string, DashboardChart[]>;

    if (Array.isArray(definition.sheets) && definition.sheets.length > 0) {
      restoredSheets = definition.sheets.map((sheet, index) => ({
        id: sheet.id ?? `restored-sheet-${index}`,
        name: sheet.name ?? `Dashboard ${index + 1}`,
      }));

      restoredChartsBySheet = Object.fromEntries(
        definition.sheets.map((sheet, sheetIndex) => {
          const sheetId = restoredSheets[sheetIndex].id;
          const sheetCharts = (sheet.charts ?? []).map((chart, chartIndex) =>
            restoreChart(
              chart,
              chartIndex,
              `${savedReport.report_id}-${sheetIndex}`,
            ),
          );

          return [sheetId, sheetCharts];
        }),
      );
    } else {
      restoredSheets = [{ id: "sheet-1", name: "Dashboard 1" }];
      restoredChartsBySheet = {
        "sheet-1": (definition.charts ?? []).map((chart, index) =>
          restoreChart(chart, index, savedReport.report_id),
        ),
      };
    }

    const firstSheetId = restoredSheets[0]?.id ?? "sheet-1";
    const firstSheetCharts = restoredChartsBySheet[firstSheetId] ?? [];

    setDashboardName(savedReport.report_name || "Saved Finance Dashboard");
    setSheets(restoredSheets);
    setActiveSheetId(firstSheetId);
    setChartsBySheet(restoredChartsBySheet);
    setSelectedChartId(firstSheetCharts[0]?.id ?? null);

    const savedFilters = definition.filters ?? {};
    const restoredFilters = Object.entries(savedFilters).map(
      ([column, value], index) => ({
        id: `restored-filter-${index}`,
        column,
        values: Array.isArray(value) ? value : [value],
      }),
    );

    setFilters(restoredFilters);
    setSelectedFilterId(null);
    setFilterOptions({});
    setFilterOptionsError({});
    setFilterOptionsLoading({});
    setRestoredReportId(savedReport.report_id);
    setChartData({});
    setChartErrors({});
    setChartLoading({});

    // Load dropdown choices for filters restored from a saved report.
    restoredFilters.forEach((filter) => {
      if (!filter.column) return;

      setFilterOptionsLoading((current) => ({
        ...current,
        [filter.id]: true,
      }));

      getFilterValues(filter.column)
        .then((response) => {
          if (!cancelled) {
            setFilterOptions((current) => ({
              ...current,
              [filter.id]: response.values ?? [],
            }));
          }
        })
        .catch((error: unknown) => {
          if (!cancelled) {
            setFilterOptionsError((current) => ({
              ...current,
              [filter.id]:
                error instanceof Error
                  ? error.message
                  : "Unable to load filter values",
            }));
          }
        })
        .finally(() => {
          if (!cancelled) {
            setFilterOptionsLoading((current) => ({
              ...current,
              [filter.id]: false,
            }));
          }
        });
    });

    return () => {
      cancelled = true;
    };
  }, [savedReport]);

  const selectedChart = useMemo(
    () => charts.find((chart) => chart.id === selectedChartId) ?? null,
    [charts, selectedChartId],
  );

  const selectedFilter =
    filters.find((filter) => filter.id === selectedFilterId) ?? null;

  // Load the dashboard field catalog.
  useEffect(() => {
    let cancelled = false;

    getDashboardCatalog()
      .then((result) => {
        if (!cancelled) {
          setCatalog(result);
          setCatalogError("");
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          setCatalogError(
            error instanceof Error ? error.message : "Catalog request failed",
          );
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // Apply dashboard filters to every chart on the active sheet.
  useEffect(() => {
    let cancelled = false;

    const filterPayload = Object.fromEntries(
      filters
        .filter((filter) => filter.column && filter.values.length > 0)
        .map((filter) => [
          filter.column,
          filter.values.length === 1 ? filter.values[0] : filter.values,
        ]),
    );

    charts.forEach((chart) => {
      setChartLoading((current) => ({ ...current, [chart.id]: true }));
      setChartErrors((current) => ({ ...current, [chart.id]: "" }));

      getDashboardChartData({
        chart_id: chart.id,
        chart_type: chart.type,
        dimension: chart.dimension,
        measure: chart.measure,
        scenario: chart.scenario as "ACT" | "DB" | "QRF",
        filters: filterPayload,
      })
        .then((result) => {
          if (!cancelled) {
            setChartData((current) => ({ ...current, [chart.id]: result }));
          }
        })
        .catch((error: unknown) => {
          if (!cancelled) {
            setChartErrors((current) => ({
              ...current,
              [chart.id]:
                error instanceof Error ? error.message : "Chart query failed",
            }));
          }
        })
        .finally(() => {
          if (!cancelled) {
            setChartLoading((current) => ({
              ...current,
              [chart.id]: false,
            }));
          }
        });
    });

    return () => {
      cancelled = true;
    };
  }, [charts, filters]);

  function addChart(type: ChartType) {
    const chart = createChart(type);
    setCharts((current) => [...current, chart]);
    setSelectedChartId(chart.id);
    setSelectedFilterId(null);
  }

  function addFilter() {
    const filter: DashboardFilter = {
      id: `filter-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      column: "",
      values: [],
    };

    setFilters((current) => [...current, filter]);
    setSelectedFilterId(filter.id);
    setSelectedChartId(null);
  }

  function addSheet() {
    const id = `sheet-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const sheetNumber = sheets.length + 1;

    setSheets((current) => [
      ...current,
      { id, name: `Dashboard ${sheetNumber}` },
    ]);
    setChartsBySheet((current) => ({ ...current, [id]: [] }));
    setActiveSheetId(id);
    setSelectedChartId(null);
    setSelectedFilterId(null);
  }

  function renameSheet(sheetId: string, name: string) {
    setSheets((current) =>
      current.map((sheet) =>
        sheet.id === sheetId
          ? { ...sheet, name: name.trim() || "Untitled sheet" }
          : sheet,
      ),
    );
  }

  function updateSelected(field: keyof DashboardChart, value: string) {
    if (!selectedChartId) return;

    setCharts((current) =>
      current.map((chart) =>
        chart.id === selectedChartId ? { ...chart, [field]: value } : chart,
      ),
    );
  }

  function removeFilter(filterId: string) {
    setFilters((current) =>
      current.filter((filter) => filter.id !== filterId),
    );

    setFilterOptions((current) => {
      const next = { ...current };
      delete next[filterId];
      return next;
    });

    setFilterOptionsLoading((current) => {
      const next = { ...current };
      delete next[filterId];
      return next;
    });

    setFilterOptionsError((current) => {
      const next = { ...current };
      delete next[filterId];
      return next;
    });

    if (selectedFilterId === filterId) {
      setSelectedFilterId(null);
    }
  }

  function removeSelected() {
    if (!selectedChartId) return;

    const removedId = selectedChartId;

    setCharts((current) =>
      current.filter((chart) => chart.id !== removedId),
    );

    setChartData((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setChartLoading((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setChartErrors((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setSelectedChartId(null);
  }

  function moveChart(targetId: string) {
    if (!draggedChartId || draggedChartId === targetId) return;

    setCharts((current) => {
      const updated = [...current];
      const fromIndex = updated.findIndex(
        (chart) => chart.id === draggedChartId,
      );
      const toIndex = updated.findIndex((chart) => chart.id === targetId);

      if (fromIndex < 0 || toIndex < 0) return current;

      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, moved);
      return updated;
    });

    setDraggedChartId(null);
  }

  function serializeChart(chart: DashboardChart) {
    return {
      chart_id: chart.id,
      title: chart.title,
      chart_type: chart.type,
      dimension: chart.dimension,
      measure: chart.measure,
      scenario: chart.scenario as "ACT" | "DB" | "QRF",
    };
  }

  async function saveDashboard() {
    const trimmedName = dashboardName.trim();

    if (!trimmedName) {
      window.alert("Please enter a dashboard name.");
      return;
    }

    if (
      Object.values(chartsBySheet).every(
        (sheetCharts) => sheetCharts.length === 0,
      )
    ) {
      window.alert("Please add at least one chart before saving.");
      return;
    }

    const serializedFilters = Object.fromEntries(
      filters
        .filter((filter) => filter.column && filter.values.length > 0)
        .map((filter) => [
          filter.column,
          filter.values.length === 1 ? filter.values[0] : filter.values,
        ]),
    );

    const definition = {
      // Preserve the flat chart field for compatibility with older reports.
      charts: (chartsBySheet[activeSheetId] ?? []).map(serializeChart),
      // Save every sheet and its charts for multi-sheet restoration.
      sheets: sheets.map((sheet) => ({
        id: sheet.id,
        name: sheet.name,
        charts: (chartsBySheet[sheet.id] ?? []).map(serializeChart),
      })),
      filters: serializedFilters,
    };

    try {
      setSaving(true);

      if (restoredReportId) {
        await updateSavedReport(restoredReportId, {
          report_name: trimmedName,
          description: "Finance dashboard created using Dashboard Studio",
          definition,
        });

        window.alert("Dashboard updated successfully!");
      } else {
        const result = await saveReport({
          report_name: trimmedName,
          description: "Finance dashboard created using Dashboard Studio",
          definition,
        });

        setRestoredReportId(result.report_id);
        window.alert("Dashboard saved successfully!");
      }

      onSaved?.();
    } catch (error) {
      console.error("Dashboard save error:", error);

      window.alert(
        error instanceof Error
          ? `Unable to save dashboard: ${error.message}`
          : "Unable to save dashboard.",
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="vf-dashboard">
      <style>{`
        .vf-dashboard{height:calc(100dvh - 82px);min-height:480px;display:flex;flex-direction:column;background:#f4f4f4;color:#252525;overflow:hidden;font-family:inherit}
        .vf-toolbar,.vf-toolbar-left,.vf-toolbar-right,.vf-layout,.vf-section-heading,.vf-sheet-tabs{display:flex;align-items:center}
        .vf-toolbar{min-height:62px;padding:0 22px;background:#fff;border-bottom:1px solid #dedede;justify-content:space-between;gap:12px;flex-shrink:0}
        .vf-toolbar-left,.vf-toolbar-right{gap:9px}
        .vf-toolbar h2{font-size:16px;margin:0 12px 0 0;font-weight:700}
        .vf-button,.vf-sheet-tab,.vf-sheet-add{border:1px solid #d6d6d6;background:#fff;color:#333;border-radius:4px;padding:9px 12px;font-size:11px;font-weight:600;cursor:pointer}
        .vf-button:disabled{opacity:.6;cursor:not-allowed}
        .vf-button:hover,.vf-sheet-tab:hover,.vf-sheet-add:hover{border-color:#E60000;color:#E60000}
        .vf-button.primary{background:#E60000;border-color:#E60000;color:#fff}
        .vf-button.primary:hover{background:#c90000}
        .vf-layout{flex:1;min-height:0;overflow:hidden;align-items:stretch}
        .vf-panel{width:220px;flex-shrink:0;overflow-y:auto;padding:17px 14px;background:#fff;border-right:1px solid #dedede}
        .vf-settings{width:245px;border-right:0;border-left:1px solid #dedede}
        .vf-panel-heading{background:#E60000;color:#fff;font-size:10px;font-weight:700;padding:10px;margin:0 0 13px}
        .vf-library-item{display:flex;align-items:center;gap:10px;width:100%;padding:11px 9px;margin-bottom:7px;background:#fff;border:1px solid #e5e5e5;border-radius:3px;text-align:left;color:#292929;cursor:pointer}
        .vf-library-item:hover{border-color:#E60000;background:#fffafa}
        .vf-library-icon{width:30px;height:30px;display:grid;place-items:center;background:#fce9e9;color:#E60000;font-size:16px;flex-shrink:0}
        .vf-library-item strong,.vf-library-item small{display:block}
        .vf-library-item strong{font-size:10px;margin-bottom:3px}
        .vf-library-item small{color:#777;font-size:9px}
        .vf-canvas{flex:1;min-width:0;min-height:0;padding:22px;background:#f4f4f4;display:flex;flex-direction:column;overflow:hidden}
        .vf-canvas-content{flex:1;min-height:0;overflow:auto}
        .vf-sheet-tabs{flex-shrink:0;gap:6px;overflow-x:auto;padding-top:10px;margin-top:12px;border-top:1px solid #dedede;background:#f4f4f4}
        .vf-sheet-tab{white-space:nowrap}
        .vf-sheet-tab.active{border-color:#E60000;color:#E60000;background:#fffafa}
        .vf-sheet-rename{width:120px;padding:8px;border:1px solid #E60000;border-radius:4px;font-size:11px}
        .vf-sheet-add{font-size:16px;padding:5px 12px}
        .vf-section-heading{background:#E60000;color:#fff;padding:12px 15px;margin-bottom:17px;justify-content:space-between;gap:10px}
        .vf-section-heading input{width:min(500px,75%);background:transparent;color:#fff;border:0;outline:none;font-size:15px;font-weight:700}
        .vf-section-heading input::placeholder{color:#fff}
        .vf-count{font-size:10px;white-space:nowrap}
        .vf-chart-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px;align-items:start}
        .vf-chart-card{min-width:0;min-height:215px;overflow:auto;resize:both;padding:15px;background:#fff;border:1px solid #dedede;border-radius:3px;cursor:grab;position:relative}
        .vf-chart-card:active{cursor:grabbing}
        .vf-chart-card.selected{border:2px solid #E60000;padding:14px}
        .vf-chart-card.dragging{opacity:.45}
        .vf-chart-card:first-child{grid-column:span 2;min-height:165px}
        .vf-chart-header{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:15px;padding-bottom:10px;border-bottom:1px solid #e9e9e9}
        .vf-chart-header strong{font-size:12px;color:#333}
        .vf-chart-header span{font-size:9px;color:#777;background:#f3f3f3;padding:5px 7px}
        .vf-kpi-preview{min-height:95px;display:flex;flex-direction:column;align-items:flex-start;position:relative}
        .vf-small-label{color:#777;font-size:9px;font-weight:700;letter-spacing:.6px}
        .vf-kpi-preview>strong{color:#A40000;font-size:30px;margin:7px 0 3px}
        .vf-data-caption{color:#777;font-size:10px}
        .vf-mini-bars{position:absolute;right:8px;bottom:0;width:35%;height:65px;display:flex;align-items:flex-end;gap:5px}
        .vf-mini-bars i{flex:1;background:#E60000;opacity:.8}
        .vf-bar-preview{display:flex;flex-direction:column;gap:14px;padding:8px 0}
        .vf-bar-row{display:grid;grid-template-columns:minmax(55px,90px) minmax(30px,1fr) 55px;align-items:center;gap:9px;color:#555;font-size:9px}
        .vf-bar-row>span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .vf-bar-row strong{text-align:right;color:#333}
        .vf-bar-track{height:9px;background:#ededed}
        .vf-bar-track i{display:block;height:100%;background:#E60000}
        .vf-line-preview{height:145px}
        .vf-line-preview svg{height:120px;width:100%}
        .vf-axis-labels{display:flex;justify-content:space-between;gap:8px;font-size:8px;color:#777;overflow:hidden}
        .vf-axis-labels span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .vf-donut-layout{display:flex;align-items:center;justify-content:center;gap:25px}
        .vf-donut{width:120px;height:120px;border-radius:50%;display:grid;place-items:center;flex-shrink:0}
        .vf-donut-hole{width:76px;height:76px;background:#fff;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center}
        .vf-donut-hole strong{font-size:13px;color:#333}
        .vf-donut-hole span{font-size:9px;color:#888}
        .vf-legend{display:flex;flex-direction:column;gap:10px;min-width:100px;max-height:145px;overflow:auto}
        .vf-legend>div{display:grid;grid-template-columns:8px 1fr auto;align-items:center;gap:6px;font-size:9px;color:#555}
        .vf-legend strong{color:#333}
        .vf-dot{width:7px;height:7px;border-radius:50%}
        .vf-table{font-size:10px;max-height:260px;overflow:auto}
        .vf-table-row{display:grid;grid-template-columns:1fr auto;gap:12px;padding:10px 5px;border-bottom:1px solid #ededed;color:#555}
        .vf-table-row strong{color:#333}
        .vf-table-head{color:#777;font-weight:700;background:#f7f7f7}
        .vf-field{margin-bottom:15px}
        .vf-field label{display:block;margin-bottom:7px;color:#555;font-size:10px;font-weight:600}
        .vf-field input,.vf-field select{width:100%;box-sizing:border-box;padding:9px;border:1px solid #d6d6d6;border-radius:3px;background:#fff;color:#333;font-size:10px;outline:none}
        .vf-field input:focus,.vf-field select:focus{border-color:#E60000}
        .vf-field select:disabled{background:#f5f5f5;color:#777;cursor:wait}
        .vf-delete{width:100%;padding:9px;border:1px solid #E60000;background:#fff;color:#E60000;font-size:10px;cursor:pointer}
        .vf-delete:hover{background:#fff1f1}
        .vf-empty{min-height:260px;padding:20px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:#fff;border:1px dashed #ccc}
        .vf-empty strong{font-size:14px;color:#333;margin-bottom:7px}
        .vf-empty p,.vf-hint{font-size:10px;color:#777;line-height:1.6}
        .vf-hint{margin-top:14px}
        .vf-selection-hint{padding:12px;border:1px dashed #ccc;color:#777;font-size:10px;line-height:1.7}
        .vf-data-state,.vf-data-error{padding:24px 12px;text-align:center;font-size:11px;color:#777;background:#fafafa;border:1px dashed #ddd}
        .vf-data-error{color:#a40000;background:#fff8f8;border-color:#e8baba;overflow-wrap:anywhere}
        .vf-catalog-warning{margin:0 0 12px;padding:9px;background:#fff8e8;color:#795b1b;font-size:10px}
        .vf-filter-container{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
        .vf-filter-chip{display:flex;align-items:center;gap:6px;padding:5px 8px;background:#fff;border:1px solid #ddd;font-size:10px;cursor:pointer}
        .vf-filter-chip.selected{border-color:#E60000;background:#fffafa}
        .vf-filter-label{font-weight:600;color:#555;white-space:nowrap}
        .vf-filter-dropdown{max-width:180px;min-width:105px;padding:5px;border:1px solid #ddd;background:#fff;color:#555;font-size:10px}
        .vf-filter-dropdown:disabled{background:#f5f5f5;color:#777;cursor:wait}
        .vf-filter-remove{border:0;background:transparent;color:#a40000;font-size:16px;cursor:pointer}
        .vf-filter-help{margin-top:7px;color:#777;font-size:9px;line-height:1.5}
        .vf-filter-error{color:#a40000}
        @media(max-width:950px){.vf-panel{width:185px}.vf-settings{width:210px}}
        @media(max-width:680px){.vf-panel{position:absolute;z-index:10;top:145px;bottom:0;box-shadow:0 5px 20px #0002}.vf-settings{right:0}.vf-chart-grid{grid-template-columns:1fr}.vf-chart-card:first-child{grid-column:span 1}.vf-toolbar{padding:0 10px}.vf-toolbar h2{display:none}.vf-canvas{padding:12px}}
      `}</style>

      <header className="vf-toolbar">
        <div className="vf-toolbar-left">
          <h2>Dashboard Studio</h2>
          <button
            className="vf-button"
            onClick={() => setShowLibrary((value) => !value)}
          >
            {showLibrary ? "← Hide charts" : "☰ Chart library"}
          </button>
          <button
            className="vf-button"
            onClick={() => setShowSettings((value) => !value)}
          >
            {showSettings ? "Hide settings →" : "⚙ Configure"}
          </button>
        </div>
        <div className="vf-toolbar-right">
          <button
            className="vf-button primary"
            onClick={() => void saveDashboard()}
            disabled={saving}
          >
            {saving
              ? "Saving..."
              : restoredReportId
                ? "Update dashboard"
                : "Save dashboard"}
          </button>
        </div>
      </header>

      <div className="vf-layout">
        {showLibrary && (
          <aside className="vf-panel">
            <h3 className="vf-panel-heading">Chart library</h3>

            <button className="vf-library-item" onClick={addFilter}>
              <span className="vf-library-icon">⌕</span>
              <span>
                <strong>Filter</strong>
                <small>Add dashboard filter</small>
              </span>
            </button>

            {chartLibrary.map((item) => (
              <button
                className="vf-library-item"
                key={item.type}
                onClick={() => addChart(item.type)}
              >
                <span className="vf-library-icon">{item.icon}</span>
                <span>
                  <strong>{item.label}</strong>
                  <small>{item.description}</small>
                </span>
              </button>
            ))}

            <p className="vf-hint">
              Select a visual to add it to your dashboard.
            </p>
          </aside>
        )}

        <main className="vf-canvas">
          <div className="vf-canvas-content">
            <div className="vf-section-heading">
              <input
                aria-label="Dashboard name"
                value={dashboardName}
                onChange={(event) => setDashboardName(event.target.value)}
              />
              <span className="vf-count">
                {charts.length} visuals
                {restoredReportId ? " · Restored report" : ""}
                {filters.some(
                  (filter) => filter.column && filter.values.length > 0,
                )
                  ? " · Filters applied"
                  : ""}
              </span>
            </div>

            <div className="vf-filter-container">
              {filters.map((filter) => {
                const label =
                  filterColumns.find((column) => column.value === filter.column)
                    ?.label ?? filter.column;

                return (
                  <div
                    key={filter.id}
                    className={`vf-filter-chip ${
                      selectedFilterId === filter.id ? "selected" : ""
                    }`}
                    onClick={() => {
                      setSelectedFilterId(filter.id);
                      setSelectedChartId(null);
                    }}
                  >
                    <span className="vf-filter-label">
                      {label || "Select Column"}
                    </span>
                    <select
                      className="vf-filter-dropdown"
                      aria-label={`Select ${label || "filter"} value`}
                      value={filter.values[0] ?? ""}
                      disabled={
                        !filter.column || !!filterOptionsLoading[filter.id]
                      }
                      onClick={(event) => event.stopPropagation()}
                      onChange={(event) => {
                        updateFilter(filter.id, {
                          values: event.target.value
                            ? [event.target.value]
                            : [],
                        });
                      }}
                    >
                      <option value="">
                        {!filter.column
                          ? "Select column first"
                          : filterOptionsLoading[filter.id]
                            ? "Loading values…"
                            : "Select values"}
                      </option>
                      {(filterOptions[filter.id] ?? []).map((value) => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                    </select>
                    <button
                      className="vf-filter-remove"
                      type="button"
                      aria-label={`Remove ${label || "filter"}`}
                      onClick={(event) => {
                        event.stopPropagation();
                        removeFilter(filter.id);
                      }}
                    >
                      ×
                    </button>
                  </div>
                );
              })}
            </div>

            {catalogError && (
              <div className="vf-catalog-warning">
                Could not refresh the field catalog. Showing the default field
                list. {catalogError}
              </div>
            )}

            {charts.length === 0 ? (
              <div className="vf-empty">
                <strong>This sheet is ready to build</strong>
                <p>Add a KPI, table or chart from the chart library.</p>
                <button
                  className="vf-button primary"
                  onClick={() => addChart("kpi")}
                >
                  Add your first KPI
                </button>
              </div>
            ) : (
              <div className="vf-chart-grid">
                {charts.map((chart) => (
                  <article
                    key={chart.id}
                    draggable
                    onDragStart={() => setDraggedChartId(chart.id)}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={() => moveChart(chart.id)}
                    onDragEnd={() => setDraggedChartId(null)}
                    onClick={() => {
                      setSelectedChartId(chart.id);
                      setSelectedFilterId(null);
                    }}
                    className={`vf-chart-card ${
                      selectedChartId === chart.id ? "selected" : ""
                    } ${draggedChartId === chart.id ? "dragging" : ""}`}
                  >
                    <div className="vf-chart-header">
                      <strong>{chart.title}</strong>
                      <span>
                        {
                          chartLibrary.find(
                            (item) => item.type === chart.type,
                          )?.label
                        }
                        {" · Drag to move"}
                      </span>
                    </div>
                    <ChartPreview
                      chart={chart}
                      data={chartData[chart.id]}
                      loading={!!chartLoading[chart.id]}
                      error={chartErrors[chart.id]}
                    />
                  </article>
                ))}
              </div>
            )}

            <p className="vf-hint">
              Select a chart to configure it. Drag charts to rearrange them and
              use the resize handle at the bottom-right of a chart.
            </p>
          </div>

          <div className="vf-sheet-tabs" aria-label="Dashboard sheets">
            {sheets.map((sheet) =>
              editingSheetId === sheet.id ? (
                <input
                  key={sheet.id}
                  className="vf-sheet-rename"
                  autoFocus
                  defaultValue={sheet.name}
                  aria-label="Rename sheet"
                  onBlur={(event) => {
                    renameSheet(sheet.id, event.currentTarget.value);
                    setEditingSheetId(null);
                  }}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.currentTarget.blur();
                    } else if (event.key === "Escape") {
                      setEditingSheetId(null);
                    }
                  }}
                />
              ) : (
                <button
                  key={sheet.id}
                  className={`vf-sheet-tab ${
                    activeSheetId === sheet.id ? "active" : ""
                  }`}
                  onClick={() => {
                    setActiveSheetId(sheet.id);
                    setSelectedChartId(null);
                    setSelectedFilterId(null);
                  }}
                  onDoubleClick={() => setEditingSheetId(sheet.id)}
                  title="Double-click to rename"
                >
                  {sheet.name}
                </button>
              ),
            )}
            <button
              className="vf-sheet-add"
              type="button"
              onClick={addSheet}
              aria-label="Add sheet"
              title="Add sheet"
            >
              +
            </button>
          </div>
        </main>

        {showSettings && (
          <aside className="vf-panel vf-settings">
            {selectedFilter && (
              <>
                <h3 className="vf-panel-heading">Filter Configuration</h3>

                <div className="vf-field">
                  <label htmlFor="filter-column">Column</label>
                  <select
                    id="filter-column"
                    value={selectedFilter.column}
                    onChange={(event) =>
                      handleFilterColumnChange(
                        selectedFilter.id,
                        event.target.value,
                      )
                    }
                  >
                    <option value="">Select Column</option>
                    {filterColumns.map((column) => {
                      const usedByAnotherFilter = filters.some(
                        (filter) =>
                          filter.id !== selectedFilter.id &&
                          filter.column === column.value,
                      );

                      return (
                        <option
                          key={column.value}
                          value={column.value}
                          disabled={usedByAnotherFilter}
                        >
                          {column.label}
                        </option>
                      );
                    })}
                  </select>
                </div>

                {selectedFilter.column && (
                  <div className="vf-field">
                    <label htmlFor="filter-values">Values</label>
                    <select
                      id="filter-values"
                      value={selectedFilter.values[0] ?? ""}
                      disabled={
                        !!filterOptionsLoading[selectedFilter.id]
                      }
                      onChange={(event) =>
                        updateFilter(selectedFilter.id, {
                          values: event.target.value
                            ? [event.target.value]
                            : [],
                        })
                      }
                    >
                      <option value="">
                        {filterOptionsLoading[selectedFilter.id]
                          ? "Loading values…"
                          : "Select a value"}
                      </option>
                      {(filterOptions[selectedFilter.id] ?? []).map(
                        (value) => (
                          <option key={value} value={value}>
                            {value}
                          </option>
                        ),
                      )}
                    </select>

                    {filterOptionsError[selectedFilter.id] && (
                      <p className="vf-filter-help vf-filter-error">
                        {filterOptionsError[selectedFilter.id]}
                      </p>
                    )}
                  </div>
                )}
              </>
            )}

            <h3 className="vf-panel-heading">Chart configuration</h3>

            {!selectedChart ? (
              <div className="vf-selection-hint">
                {selectedFilter
                  ? "Configure the selected filter above, or select a chart to edit its settings."
                  : "Select a chart on the canvas to edit its title, dimension, measure and scenario. Select a filter chip to configure a dashboard filter."}
              </div>
            ) : (
              <>
                <div className="vf-field">
                  <label htmlFor="chart-title">Chart title</label>
                  <input
                    id="chart-title"
                    value={selectedChart.title}
                    onChange={(event) =>
                      updateSelected("title", event.target.value)
                    }
                  />
                </div>

                <div className="vf-field">
                  <label htmlFor="chart-type">Chart type</label>
                  <select
                    id="chart-type"
                    value={selectedChart.type}
                    onChange={(event) =>
                      updateSelected("type", event.target.value)
                    }
                  >
                    {chartLibrary.map((item) => (
                      <option key={item.type} value={item.type}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label htmlFor="chart-dimension">Dimension</label>
                  <select
                    id="chart-dimension"
                    value={selectedChart.dimension}
                    onChange={(event) =>
                      updateSelected("dimension", event.target.value)
                    }
                  >
                    {catalog.dimensions.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label htmlFor="chart-measure">Measure</label>
                  <select
                    id="chart-measure"
                    value={selectedChart.measure}
                    onChange={(event) =>
                      updateSelected("measure", event.target.value)
                    }
                  >
                    {catalog.measures.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label htmlFor="chart-scenario">Scenario</label>
                  <select
                    id="chart-scenario"
                    value={selectedChart.scenario}
                    onChange={(event) =>
                      updateSelected("scenario", event.target.value)
                    }
                  >
                    {catalog.scenarios.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <button className="vf-delete" onClick={removeSelected}>
                  Remove chart
                </button>
              </>
            )}
          </aside>
        )}
      </div>
    </section>
  );
}