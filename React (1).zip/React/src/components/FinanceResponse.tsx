
import type { FinanceResponse } from "../types/finance";

interface Props {
  response: FinanceResponse;
}

interface ComparisonItem {
  comparison_scenario?: string;
  comparison_scenario_label?: string;
  actual_value?: string;
  actual_formatted?: string;
  comparison_value?: string;
  comparison_formatted?: string;
  variance?: string;
  variance_formatted?: string;
  variance_percentage?: string | null;
  variance_percentage_formatted?: string | null;
  direction?: string;
  performance_direction?: string;
  summary?: string;

  // Compatibility with the earlier frontend response format
  scenario?: string;
  scenario_label?: string;
  value?: string | number;
  formatted_value?: string;
}

function formatFilters(filters?: object | null): string {
  if (!filters || Object.keys(filters).length === 0) {
    return "No additional filters";
  }

  return Object.entries(filters as Record<string, unknown>)
    .map(
      ([key, value]) =>
        `${key.replace(/_/g, " ")}: ${
          Array.isArray(value) ? value.join(", ") : String(value)
        }`
    )
    .join("  ·  ");
}

function getVarianceClass(direction?: string): string {
  const normalized = (direction || "").toLowerCase();

  if (
    normalized.includes("favourable") ||
    normalized.includes("positive") ||
    normalized.includes("above")
  ) {
    return "comparison-positive";
  }

  if (
    normalized.includes("unfavourable") ||
    normalized.includes("negative") ||
    normalized.includes("below")
  ) {
    return "comparison-negative";
  }

  return "comparison-neutral";
}

function ComparisonCards({
  results,
}: {
  results: ComparisonItem[];
}) {
  return (
    <div className="comparison-results">
      {results.map((item, index) => {
        const scenario =
          item.comparison_scenario ||
          item.scenario ||
          `Comparison ${index + 1}`;

        const scenarioLabel =
          item.comparison_scenario_label ||
          item.scenario_label ||
          scenario;

        const direction =
          item.performance_direction || item.direction;

        return (
          <article
            className="comparison-report-card"
            key={`${scenario}-${index}`}
          >
            <div className="comparison-report-header">
              <div>
                <span className="eyebrow">
                  SCENARIO COMPARISON
                </span>
                <h4>Actuals vs {scenarioLabel}</h4>
              </div>

              {direction && (
                <span
                  className={`comparison-direction ${getVarianceClass(
                    direction
                  )}`}
                >
                  {direction}
                </span>
              )}
            </div>

            <div className="comparison-kpi-grid">
              <div className="comparison-kpi">
                <span className="card-label">Actuals</span>
                <strong className="comparison-kpi-value">
                  {item.actual_formatted ??
                    item.actual_value ??
                    "—"}
                </strong>
              </div>

              <div className="comparison-kpi">
                <span className="card-label">
                  {scenarioLabel}
                </span>
                <strong className="comparison-kpi-value">
                  {item.comparison_formatted ??
                    item.formatted_value ??
                    item.comparison_value ??
                    item.value ??
                    "—"}
                </strong>
              </div>

              <div
                className={`comparison-kpi comparison-variance ${getVarianceClass(
                  direction
                )}`}
              >
                <span className="card-label">Variance</span>
                <strong className="comparison-kpi-value">
                  {item.variance_formatted ??
                    item.variance ??
                    "—"}
                </strong>
              </div>

              <div className="comparison-kpi">
                <span className="card-label">Variance %</span>
                <strong className="comparison-kpi-value">
                  {item.variance_percentage_formatted ??
                    item.variance_percentage ??
                    "N/A"}
                </strong>
              </div>
            </div>

            {item.summary && (
              <div className="comparison-insight">
                <span className="card-label">
                  COMPARISON INSIGHT
                </span>
                <p>{item.summary}</p>
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}

export function FinanceResponseView({ response }: Props) {
  const analysisComparisons = (
    response.analysis?.comparisons ?? []
  ) as unknown as ComparisonItem[];

  const comparisonResults = analysisComparisons;

  const isComparison =
    response.query_type === "comparison";

  return (
    <section
      className={`answer-panel ${
        isComparison ? "answer-panel-comparison" : ""
      }`}
    >
      <div className="answer-heading">
        <div className="answer-icon">✦</div>

        <div className="answer-heading-content">
          <span className="eyebrow">FINANCE ANALYSIS</span>
          <h3>
            {response.metric_label ||
              response.metric ||
              "Analysis result"}
          </h3>
        </div>

        <span className="success-pill">Completed</span>
      </div>

      {response.message && (
        <p className="answer-message">{response.message}</p>
      )}

      {isComparison ? (
        <div className="comparison-section">
          {comparisonResults.length > 0 ? (
            <ComparisonCards results={comparisonResults} />
          ) : (
            <div className="comparison-empty">
              <p>
                The comparison response did not contain
                calculated scenario values.
              </p>
            </div>
          )}

          {response.analysis &&
            typeof response.analysis.summary === "string" && (
              <div className="comparison-overall-summary">
                <span className="card-label">
                  OVERALL ANALYSIS
                </span>
                <p>{response.analysis.summary}</p>
              </div>
            )}
        </div>
      ) : (
        <div className="single-result-card">
          <span className="card-label">
            {response.scenario_label ||
              response.scenario ||
              "Result"}
          </span>

          <strong className="result-value">
            {response.formatted_value ??
              String(response.value ?? "—")}
          </strong>

          {response.interpretation && (
            <p>{response.interpretation}</p>
          )}
        </div>
      )}

      <div className="filter-summary">
        <span className="card-label">APPLIED FILTERS</span>
        <p>{formatFilters(response.filters)}</p>
      </div>
    </section>
  );
}
