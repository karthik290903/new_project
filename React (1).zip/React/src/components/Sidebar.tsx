const navigation = [
  { label: "Finance Assistant", icon: "✦" },
  { label: "Data Explorer", icon: "▦" },
  { label: "Data Analyzer", icon: "▤" },
  { label: "Visualizations", icon: "▥" },
  { label: "Saved Reports", icon: "▤" },
];
interface SidebarProps { activePage: string; onNavigate: (page: string) => void; }
export function Sidebar({ activePage, onNavigate }: SidebarProps) {
  return <aside className="sidebar">
    <div className="brand-lockup">
      <img className="vodafone-logo" src="https://upload.wikimedia.org/wikipedia/commons/e/ef/Vodafone_Logo.svg" alt="Vodafone logo" />
      <div><strong>VBI Finance</strong><small>INTELLIGENCE PLATFORM</small></div>
    </div>
    <button className="new-analysis" onClick={() => onNavigate("Finance Assistant")}><span>＋</span> New analysis</button>
    <p className="nav-caption">WORKSPACE</p>
    <nav>{navigation.map(item => <button key={item.label} className={`nav-item ${activePage === item.label ? "active" : ""}`} onClick={() => onNavigate(item.label)}><span className="nav-icon">{item.icon}</span>{item.label}</button>)}</nav>
    <div className="sidebar-bottom"><div className="environment"><span /> POC ENVIRONMENT</div><div className="user-profile"><div className="avatar">FA</div><div><strong>Finance Analyst</strong><small>Workspace user</small></div><span className="profile-menu">···</span></div></div>
  </aside>;
}
