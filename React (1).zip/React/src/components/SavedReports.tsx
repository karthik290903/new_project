
import { useEffect, useState } from "react";
import {
  deleteSavedReport,
  getSavedReports,
  getSavedReport,
  type SavedReport,
} from "../services/reportsApi";

interface SavedReportsProps {
  onOpenReport: (report: SavedReport) => void;
  refreshKey?: number;
}

export default function SavedReports({
  onOpenReport,
  refreshKey = 0,
}: SavedReportsProps) {
  const [reports, setReports] = useState<SavedReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [openingId, setOpeningId] = useState<string | null>(null);

  async function loadReports() {
    try {
      setLoading(true);
      setError("");

      const data = await getSavedReports();
      setReports(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to load saved reports."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadReports();
  }, [refreshKey]);

  async function handleOpen(reportId: string) {
    try {
      setOpeningId(reportId);
      setError("");

      // Fetch the complete report, including its chart definitions.
      const fullReport = await getSavedReport(reportId);

      if (!fullReport.definition) {
        throw new Error(
          "This saved report does not contain a dashboard definition."
        );
      }

      onOpenReport(fullReport);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to open this report."
      );
    } finally {
      setOpeningId(null);
    }
  }

  async function handleDelete(reportId: string) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this saved report?"
    );

    if (!confirmed) return;

    try {
      setDeletingId(reportId);
      setError("");

      await deleteSavedReport(reportId);

      setReports((current) =>
        current.filter((report) => report.report_id !== reportId)
      );
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to delete this report."
      );
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <section className="saved-reports">
      <div className="saved-reports__header">
        <div>
          <h2>Saved Reports</h2>
          <p>Access and manage your saved finance dashboards.</p>
        </div>

        <button
          type="button"
          className="saved-reports__refresh"
          onClick={() => void loadReports()}
          disabled={loading}
        >
          Refresh
        </button>
      </div>

      {loading && (
        <div className="saved-reports__message">
          Loading saved reports...
        </div>
      )}

      {!loading && error && (
        <div className="saved-reports__error">{error}</div>
      )}

      {!loading && !error && reports.length === 0 && (
        <div className="saved-reports__empty">
          <h3>No saved reports yet</h3>
          <p>
            Save a dashboard from Dashboard Studio and it will appear here.
          </p>
        </div>
      )}

      {!loading && reports.length > 0 && (
        <div className="saved-reports__grid">
          {reports.map((report) => (
            <article
              className="saved-reports__card"
              key={report.report_id}
            >
              <div className="saved-reports__card-top">
                <div className="saved-reports__icon">▤</div>
                <span className="saved-reports__status">Saved</span>
              </div>

              <h3>{report.report_name}</h3>

              <p className="saved-reports__description">
                {report.description || "No description provided."}
              </p>

              <div className="saved-reports__meta">
                {report.updated_at
                  ? `Updated ${new Date(
                      report.updated_at
                    ).toLocaleDateString()}`
                  : "Saved report"}
              </div>

              <div className="saved-reports__actions">
                <button
                  type="button"
                  className="saved-reports__open"
                  onClick={() => void handleOpen(report.report_id)}
                  disabled={
                    openingId !== null ||
                    deletingId === report.report_id
                  }
                >
                  {openingId === report.report_id
                    ? "Opening..."
                    : "Open Report"}
                </button>

                <button
                  type="button"
                  className="saved-reports__delete"
                  onClick={() => void handleDelete(report.report_id)}
                  disabled={
                    deletingId !== null ||
                    openingId === report.report_id
                  }
                  aria-label={`Delete ${report.report_name}`}
                >
                  {deletingId === report.report_id
                    ? "Deleting..."
                    : "Delete"}
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
