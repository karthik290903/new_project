import { useEffect, useMemo, useState } from "react";
import {
  getAnalyzerCatalog,
  runAnalyzerPivot,
} from "../services/api";
import type {
  AnalyzerCatalog,
  AnalyzerPivotRequest,
} from "../services/api";
import "../styles/analyzer.css";

type CatalogItem = Record<string, unknown>;
type DataRow = Record<string, unknown>;
type DimensionTarget = "rows" | "columns";

function textValue(
  item: CatalogItem,
  candidates: string[],
  fallback = ""
): string {
  for (const key of candidates) {
    const value = item[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  return fallback;
}

function normalizeItems(
  items: CatalogItem[] | undefined,
  kind: "dimension" | "measure"
) {
  return (items ?? []).map((item, index) => {
    const key =
      kind === "dimension"
        ? textValue(
            item,
            ["field", "key", "code", "name", "id"],
            `dimension_${index}`
          )
        : textValue(
            item,
            ["metric_code", "code", "key", "id", "name"],
            `measure_${index}`
          );

    const label = textValue(
      item,
      ["label", "display_name", "metric_label", "name", "title"],
      key
    );

    return {
      key,
      label,
      description: textValue(item, ["description"]),
      raw: item,
    };
  });
}

function extractRows(payload: Record<string, unknown>): DataRow[] {
  const candidates = [
    payload.data,
    payload.rows,
    payload.results,
    payload.records,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) {
      return candidate.filter(
        (item): item is DataRow =>
          !!item && typeof item === "object" && !Array.isArray(item)
      );
    }

    if (candidate && typeof candidate === "object") {
      const nested = candidate as Record<string, unknown>;

      for (const key of ["rows", "data", "records", "results"]) {
        if (Array.isArray(nested[key])) {
          return (nested[key] as unknown[]).filter(
            (item): item is DataRow =>
              !!item && typeof item === "object" && !Array.isArray(item)
          );
        }
      }
    }
  }

  return [];
}

function displayValue(value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";

  if (typeof value === "number") {
    return value.toLocaleString("en-GB", { maximumFractionDigits: 2 });
  }

  if (typeof value === "string" && /^-?\d+(\.\d+)?$/.test(value)) {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) {
      return numeric.toLocaleString("en-GB", {
        maximumFractionDigits: 2,
      });
    }
  }

  if (typeof value === "boolean") return value ? "Yes" : "No";

  return String(value);
}

export default function DataAnalyzer() {
  const [catalog, setCatalog] = useState<AnalyzerCatalog | null>(null);
  const [catalogError, setCatalogError] = useState("");
  const [loadingCatalog, setLoadingCatalog] = useState(true);

  const [selectedRows, setSelectedRows] = useState<string[]>([
    "segment",
    "region",
  ]);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    "scenario",
  ]);
  const [activeDimensionTarget, setActiveDimensionTarget] =
    useState<DimensionTarget>("rows");

  const [selectedMeasures, setSelectedMeasures] = useState<string[]>([
    "TOTAL_REVENUE",
  ]);
  const [filters, setFilters] = useState<Record<string, unknown>>({});
  const [filterField, setFilterField] = useState("scenario");
  const [filterValue, setFilterValue] = useState("ACT");
  const [includeTotals, setIncludeTotals] = useState(true);

  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    getAnalyzerCatalog()
      .then((data: AnalyzerCatalog) => {
        if (active) setCatalog(data);
      })
      .catch((err: unknown) => {
        if (active) {
          setCatalogError(
            err instanceof Error
              ? err.message
              : "Unable to load Analyzer catalog."
          );
        }
      })
      .finally(() => {
        if (active) setLoadingCatalog(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const dimensions = useMemo(
    () => normalizeItems(catalog?.dimensions, "dimension"),
    [catalog]
  );

  const measures = useMemo(
    () => normalizeItems(catalog?.measures, "measure"),
    [catalog]
  );

  const rows = useMemo(
    () => (result ? extractRows(result) : []),
    [result]
  );

  const tableColumns = useMemo(() => {
    if (!rows.length) return [];
    return Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
  }, [rows]);

  function toggle(
    list: string[],
    value: string,
    setter: (next: string[]) => void
  ) {
    setter(
      list.includes(value)
        ? list.filter((item) => item !== value)
        : [...list, value]
    );
  }

  function handleDimensionSelection(field: string) {
    if (activeDimensionTarget === "rows") {
      if (selectedRows.includes(field)) {
        setSelectedRows((current) =>
          current.filter((item) => item !== field)
        );
      } else {
        setSelectedRows((current) => [...current, field]);
        setSelectedColumns((current) =>
          current.filter((item) => item !== field)
        );
      }
      return;
    }

    if (selectedColumns.includes(field)) {
      setSelectedColumns((current) =>
        current.filter((item) => item !== field)
      );
    } else {
      setSelectedColumns((current) => [...current, field]);
      setSelectedRows((current) =>
        current.filter((item) => item !== field)
      );
    }
  }

  function addFilter() {
    if (!filterField || !filterValue.trim()) return;

    setFilters((current) => ({
      ...current,
      [filterField]: [filterValue.trim()],
    }));
  }

  function removeFilter(field: string) {
    setFilters((current) => {
      const next = { ...current };
      delete next[field];
      return next;
    });
  }

  function resetLayout() {
    setSelectedRows(["segment", "region"]);
    setSelectedColumns(["scenario"]);
    setSelectedMeasures(["TOTAL_REVENUE"]);
    setActiveDimensionTarget("rows");
    setFilters({});
    setResult(null);
    setError("");
  }

  async function execute() {
    if (!selectedMeasures.length) {
      setError("Select at least one measure before running the analysis.");
      return;
    }

    setRunning(true);
    setError("");

    try {
      const request: AnalyzerPivotRequest = {
        rows: selectedRows,
        columns: selectedColumns,
        measures: selectedMeasures,
        filters,
        include_totals: includeTotals,
      };

      const response = await runAnalyzerPivot(request);
      setResult(response);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to execute the pivot query."
      );
    } finally {
      setRunning(false);
    }
  }

  if (loadingCatalog) {
    return (
      <section className="analyzer-page">
        <div className="analyzer-loading">
          <span className="analyzer-spinner" />
          Loading Analyzer catalog…
        </div>
      </section>
    );
  }

  if (catalogError) {
    return (
      <section className="analyzer-page">
        <div className="analyzer-error">
          <strong>Unable to load Data Analyzer</strong>
          <p>{catalogError}</p>
          <span>
            Check that the FastAPI backend is running and the Analyzer catalog
            endpoint is available.
          </span>
        </div>
      </section>
    );
  }

  return (
    <section className="analyzer-page">
      <div className="analyzer-heading">
        <div>
          <div className="analyzer-eyebrow">
            SELF-SERVICE FINANCIAL ANALYSIS
          </div>
          <h2>Data Analyzer</h2>
          <p>Build a multidimensional view of your financial data.</p>
        </div>

        <div className="analyzer-source">
          <span />
          Synthetic CSV · POC data
        </div>
      </div>

      <div className="analyzer-workspace">
        <aside className="analyzer-builder">
          <div className="analyzer-panel-title">
            <div>
              <strong>Data</strong>
              <small>
                {dimensions.length} dimensions · {measures.length} measures
              </small>
            </div>
            <span className="analyzer-data-icon">▦</span>
          </div>

          <div className="analyzer-field-section">
            <h3>DIMENSIONS</h3>
            <div className="analyzer-field-list">
              {dimensions.map((item) => {
                const isSelectedInActiveTarget =
                  activeDimensionTarget === "rows"
                    ? selectedRows.includes(item.key)
                    : selectedColumns.includes(item.key);

                const isSelectedAnywhere =
                  selectedRows.includes(item.key) ||
                  selectedColumns.includes(item.key);

                return (
                  <label className="analyzer-field" key={item.key} title={item.description}>
                    <input
                      type="checkbox"
                      checked={isSelectedInActiveTarget}
                      aria-label={`${item.label} in ${activeDimensionTarget}`}
                      onChange={() => handleDimensionSelection(item.key)}
                    />
                    <span className="analyzer-field-glyph">▤</span>
                    <span>{item.label}</span>
                    {isSelectedAnywhere && (
                      <small className="analyzer-field-placement">
                        {selectedRows.includes(item.key) ? "Row" : "Column"}
                      </small>
                    )}
                  </label>
                );
              })}
            </div>
          </div>

          <div className="analyzer-field-section">
            <h3>MEASURES</h3>
            <div className="analyzer-field-list">
              {measures.map((item) => (
                <label className="analyzer-field" key={item.key} title={item.description}>
                  <input
                    type="checkbox"
                    checked={selectedMeasures.includes(item.key)}
                    onChange={() =>
                      toggle(
                        selectedMeasures,
                        item.key,
                        setSelectedMeasures
                      )
                    }
                  />
                  <span className="analyzer-measure-glyph">∑</span>
                  <span>{item.label}</span>
                </label>
              ))}
            </div>
          </div>
        </aside>

        <div className="analyzer-main">
          <div className="analyzer-layout-card">
            <div className="analyzer-card-heading">
              <div>
                <strong>Analysis layout</strong>
                <small>Choose how your data is arranged</small>
              </div>
              <button
                className="analyzer-text-button"
                onClick={resetLayout}
                type="button"
              >
                Reset layout
              </button>
            </div>

            <div className="analyzer-drop-grid">
              <div
                className={`analyzer-drop-zone ${
                  activeDimensionTarget === "rows" ? "active" : ""
                }`}
                onClick={() => setActiveDimensionTarget("rows")}
              >
                <button
                  type="button"
                  className={`analyzer-zone-selector ${
                    activeDimensionTarget === "rows" ? "active" : ""
                  }`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setActiveDimensionTarget("rows");
                  }}
                >
                  ROWS {activeDimensionTarget === "rows" ? "✓" : ""}
                </button>

                <div className="analyzer-chips">
                  {selectedRows.length ? (
                    selectedRows.map((field) => (
                      <button
                        key={field}
                        className="analyzer-chip"
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          toggle(selectedRows, field, setSelectedRows);
                        }}
                      >
                        {dimensions.find((item) => item.key === field)?.label ??
                          field}
                        <span>×</span>
                      </button>
                    ))
                  ) : (
                    <span className="analyzer-empty-chip">
                      Add dimensions from the Data panel
                    </span>
                  )}
                </div>
              </div>

              <div
                className={`analyzer-drop-zone ${
                  activeDimensionTarget === "columns" ? "active" : ""
                }`}
                onClick={() => setActiveDimensionTarget("columns")}
              >
                <button
                  type="button"
                  className={`analyzer-zone-selector ${
                    activeDimensionTarget === "columns" ? "active" : ""
                  }`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setActiveDimensionTarget("columns");
                  }}
                >
                  COLUMNS {activeDimensionTarget === "columns" ? "✓" : ""}
                </button>

                <div className="analyzer-chips">
                  {selectedColumns.length ? (
                    selectedColumns.map((field) => (
                      <button
                        key={field}
                        className="analyzer-chip"
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          toggle(
                            selectedColumns,
                            field,
                            setSelectedColumns
                          );
                        }}
                      >
                        {dimensions.find((item) => item.key === field)?.label ??
                          field}
                        <span>×</span>
                      </button>
                    ))
                  ) : (
                    <span className="analyzer-empty-chip">
                      Add dimensions from the Data panel
                    </span>
                  )}
                </div>
              </div>

              <div className="analyzer-drop-zone">
                <h3>MEASURES</h3>
                <div className="analyzer-chips">
                  {selectedMeasures.length ? (
                    selectedMeasures.map((field) => (
                      <button
                        key={field}
                        className="analyzer-chip analyzer-chip-measure"
                        type="button"
                        onClick={() =>
                          toggle(
                            selectedMeasures,
                            field,
                            setSelectedMeasures
                          )
                        }
                      >
                        {measures.find((item) => item.key === field)?.label ??
                          field}
                        <span>×</span>
                      </button>
                    ))
                  ) : (
                    <span className="analyzer-empty-chip">
                      Select at least one measure
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="analyzer-filter-row">
              <div className="analyzer-filter-title">
                <strong>Filters</strong>
                <small>Apply a filter to the result</small>
              </div>

              <select
                value={filterField}
                onChange={(event) => setFilterField(event.target.value)}
                aria-label="Filter field"
              >
                {dimensions.map((item) => (
                  <option key={item.key} value={item.key}>
                    {item.label}
                  </option>
                ))}
              </select>

              <input
                value={filterValue}
                onChange={(event) => setFilterValue(event.target.value)}
                placeholder="Filter value"
                aria-label="Filter value"
              />

              <button
                className="analyzer-add-filter"
                onClick={addFilter}
                type="button"
              >
                Add filter
              </button>
            </div>

            {Object.entries(filters).length > 0 && (
              <div className="analyzer-active-filters">
                {Object.entries(filters).map(([field, values]) => (
                  <span key={field}>
                    {field}:{" "}
                    {Array.isArray(values) ? values.join(", ") : String(values)}
                    <button
                      onClick={() => removeFilter(field)}
                      aria-label={`Remove ${field} filter`}
                      type="button"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}

            <div className="analyzer-run-row">
              <label>
                <input
                  type="checkbox"
                  checked={includeTotals}
                  onChange={(event) => setIncludeTotals(event.target.checked)}
                />
                Include subtotals and grand total
              </label>

              <button
                className="analyzer-run-button"
                onClick={() => void execute()}
                disabled={running || !selectedMeasures.length}
                type="button"
              >
                {running ? "Running analysis…" : "Run analysis"}
                <span>→</span>
              </button>
            </div>
          </div>

          {error && (
            <div className="analyzer-error">
              <strong>Analysis could not be completed</strong>
              <p>{error}</p>
            </div>
          )}

          <div className="analyzer-results-card">
            <div className="analyzer-results-heading">
              <div>
                <strong>Results</strong>
                <small>
                  {result
                    ? `${rows.length} result rows`
                    : "Your pivot table will appear here"}
                </small>
              </div>

              {result && (
                <span className="analyzer-success-pill">Query complete</span>
              )}
            </div>

            {!result ? (
              <div className="analyzer-empty-state">
                <div>▦</div>
                <strong>Build your financial view</strong>
                <p>
                  Select dimensions and measures, then run the analysis.
                </p>
              </div>
            ) : rows.length === 0 ? (
              <div className="analyzer-empty-state">
                <strong>
                  Query completed, but no tabular rows were found.
                </strong>
                <p>
                  Response keys: {Object.keys(result).join(", ") || "none"}.
                  Share this response so we can align the table renderer to
                  the backend schema.
                </p>
                <pre>{JSON.stringify(result, null, 2)}</pre>
              </div>
            ) : (
              <div className="analyzer-table-wrap">
                <table className="analyzer-table">
                  <thead>
                    <tr>
                      {tableColumns.map((column) => (
                        <th key={column}>
                          {column.replace(/^g_/, "").replace(/_/g, " ")}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, index) => (
                      <tr key={index}>
                        {tableColumns.map((column) => (
                          <td
                            key={column}
                            className={
                              column.startsWith("g_")
                                ? "analyzer-meta-cell"
                                : ""
                            }
                          >
                            {displayValue(row[column])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="analyzer-footnote">
            This workspace currently uses synthetic demonstration data. Other
            VBI Finance modules continue to use their existing data
            connections.
          </div>
        </div>
      </div>
    </section>
  );
}
