import type { FinanceResponse } from "../types/finance";
import type { VisualizationRequest, VisualizationResponse } from "../types/visualization";

// Leave empty when using the Vite development proxy.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

export async function askFinance(question: string): Promise<FinanceResponse> {
  const response = await fetch(`${API_BASE_URL}/api/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ question }),
  });

  const payload: unknown = await response.json().catch(() => null);

  if (!response.ok) {
    const detail =
      payload && typeof payload === "object" && "detail" in payload
        ? (payload as { detail?: unknown }).detail
        : undefined;
    throw new Error(typeof detail === "string" ? detail : `Request failed (${response.status})`);
  }

  return payload as FinanceResponse;
}


export async function generateVisualization(request: VisualizationRequest): Promise<VisualizationResponse> {
  const response = await fetch(`${API_BASE_URL}/api/visualizations`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(request),
  });
  const payload: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = payload && typeof payload === "object" && "detail" in payload
      ? (payload as { detail?: unknown }).detail : undefined;
    throw new Error(typeof detail === "string" ? detail : `Visualization request failed (${response.status})`);
  }
  return payload as VisualizationResponse;
}
 
export interface AnalyzerCatalog {
  status?: string;
  data_source?: string;
  dimensions: Array<Record<string, unknown>>;
  measures: Array<Record<string, unknown>>;
  filters?: Array<Record<string, unknown>>;
  scenarios?: Array<Record<string, unknown>>;
  supported_layouts?: string[];
  capabilities?: Record<string, boolean>;
}
 
export interface AnalyzerPivotRequest {
  rows: string[];
  columns: string[];
  measures: string[];
  filters: Record<string, unknown>;
  include_totals: boolean;
}
 
export async function getAnalyzerCatalog(): Promise<AnalyzerCatalog> {
  const response = await fetch(`${API_BASE_URL}/api/analyzer/catalog`, {
    headers: { Accept: "application/json" },
  });
 
  const payload: unknown = await response.json().catch(() => null);
 
  if (!response.ok) {
    throw new Error(`Analyzer catalog failed (${response.status})`);
  }
 
  return payload as AnalyzerCatalog;
}
 
export async function runAnalyzerPivot(
  request: AnalyzerPivotRequest
): Promise<Record<string, unknown>> {
  const response = await fetch(`${API_BASE_URL}/api/analyzer/pivot`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(request),
  });
 
  const payload: unknown = await response.json().catch(() => null);
 
  if (!response.ok) {
    throw new Error(`Analyzer pivot failed (${response.status})`);
  }
 
  return payload as Record<string, unknown>;
}
 