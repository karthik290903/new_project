
const API_BASE_URL = "/api";

export interface SavedReportDefinition {
  charts: Array<{
    chart_id: string;
    title?: string;
    chart_type: string;
    dimension: string;
    measure: string;
    scenario: "ACT" | "DB" | "QRF";
    [key: string]: unknown;
  }>;
  filters?: Record<string, string | string[]>;
  [key: string]: unknown;
}

export interface SavedReport {
  report_id: string;
  report_name: string;
  description: string | null;
  created_by?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  definition?: SavedReportDefinition;
  is_active?: boolean;
}

export interface SaveReportRequest {
  report_name: string;
  description?: string;
  created_by?: string;
  definition: SavedReportDefinition;
}

export interface UpdateReportRequest {
  report_name: string;
  description?: string;
  definition: SavedReportDefinition;
}

interface ApiMessageResponse {
  status: string;
  message: string;
  report_id: string;
}

interface ApiListResponse {
  status: string;
  total_reports: number;
  reports: SavedReport[];
}

interface ApiSingleResponse {
  status: string;
  report: SavedReport;
}

async function reportsRequest<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    let message = `Reports API error: ${response.status}`;

    try {
      const errorBody = await response.json();
      message =
        errorBody.detail ||
        errorBody.message ||
        message;
    } catch {
      const text = await response.text();
      if (text) message = text;
    }

    throw new Error(message);
  }

  return response.json() as Promise<T>;
}

// Save a new report.
export async function saveReport(
  request: SaveReportRequest
): Promise<SavedReport> {
  const result = await reportsRequest<ApiMessageResponse>(
    "/reports",
    {
      method: "POST",
      body: JSON.stringify(request),
    }
  );

  return {
    report_id: result.report_id,
    report_name: request.report_name,
    description: request.description ?? null,
    definition: request.definition,
  };
}

// Get all active saved reports.
export async function getSavedReports(): Promise<SavedReport[]> {
  const result = await reportsRequest<ApiListResponse>("/reports");
  return result.reports ?? [];
}

// Get one saved report, including its dashboard definition.
export async function getSavedReport(
  reportId: string
): Promise<SavedReport> {
  const result = await reportsRequest<ApiSingleResponse>(
    `/reports/${encodeURIComponent(reportId)}`
  );

  return result.report;
}

// Update an existing report.
export async function updateSavedReport(
  reportId: string,
  request: UpdateReportRequest
): Promise<SavedReport> {
  const result = await reportsRequest<ApiMessageResponse>(
    `/reports/${encodeURIComponent(reportId)}`,
    {
      method: "PUT",
      body: JSON.stringify(request),
    }
  );

  return {
    report_id: result.report_id,
    report_name: request.report_name,
    description: request.description ?? null,
    definition: request.definition,
  };
}

// Delete (soft-delete) a saved report.
export function deleteSavedReport(
  reportId: string
): Promise<ApiMessageResponse> {
  return reportsRequest<ApiMessageResponse>(
    `/reports/${encodeURIComponent(reportId)}`,
    {
      method: "DELETE",
    }
  );
}
