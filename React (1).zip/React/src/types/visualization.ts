export type VisualizationMetric = "service_revenue" | "non_service_revenue" | "total_revenue" | "cost_of_sales";
export type VisualizationScenario = "ACT" | "DB" | "QRF";
export type VisualizationDimension = "region" | "segment" | "country" | "product" | "financial_period";
export interface VisualizationRequest {
  metric: VisualizationMetric;
  scenario: VisualizationScenario;
  dimension: VisualizationDimension;
  filters?: { financial_period?: string; segment?: string; region?: string; country?: string; product?: string };
}
export interface VisualizationDataPoint { category: string | null; value: number }
export interface VisualizationResponse {
  status: string; metric: string; metric_label: string; scenario: VisualizationScenario;
  scenario_label: string; dimension: VisualizationDimension; filters: Record<string, unknown>;
  data: VisualizationDataPoint[]; total_rows: number; job_id: string;
}
