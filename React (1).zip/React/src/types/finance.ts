export interface FinanceFilters {
  financial_period?: string;
  segment?: string;
  region?: string;
  customer_id?: string;
  customer_name?: string;
  product?: string;
  country?: string;
}

export interface ComparisonResult {
  scenario: string;
  scenario_label: string;
  value: string | number | null;
  formatted_value: string;
  variance?: string | number | null;
  variance_formatted?: string;
  variance_percentage?: number | null;
  direction?: string;
  performance_direction?: "positive" | "negative" | "neutral" | string;
}

export interface ComparisonAnalysis {
  metric?: string;
  metric_label?: string;
  summary?: string;
  comparisons?: ComparisonResult[];
  [key: string]: unknown;
}

export interface FinanceResponse {
  status: string;
  query_type: "single" | "comparison";
  question: string;
  message?: string;
  interpretation?: string;
  metric?: string;
  metric_label?: string;
  scenario?: string;
  scenario_label?: string;
  filters?: FinanceFilters;
  value?: string | number | null;
  formatted_value?: string;
  data?: Record<string, unknown>[];
  total_rows?: number;
  job_id?: string;
  analysis?: ComparisonAnalysis;
  comparisons?: ComparisonResult[];
}
