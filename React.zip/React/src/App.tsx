
import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { FinanceResponseView } from "./components/FinanceResponse";
import VisualizationBuilder from "./components/VisualizationBuilder";
import DashboardWorkspace from "./components/DashboardWorkspace";
import SavedReports from "./components/SavedReports";
import { askFinance } from "./services/api";
import type { FinanceResponse } from "./types/finance";
import type { SavedReport } from "./services/reportsApi";
import "./App.css";

const suggestions = [
  "Show actual total revenue for Europe",
  "Compare actual revenue with Budget for IoT",
  "Show service revenue for Fixed in Asia",
  "Show cost of sales for Mobility",
];

export default function App() {
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState<FinanceResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [activePage, setActivePage] = useState("Finance Assistant");
  const [savedReportsRefreshKey, setSavedReportsRefreshKey] = useState(0);
  const [selectedReport, setSelectedReport] = useState<SavedReport | null>(
    null
  );

  async function submitQuestion(value = question) {
    const trimmed = value.trim();

    if (!trimmed || loading) return;

    setQuestion(trimmed);
    setLoading(true);
    setError("");
    setResponse(null);

    try {
      const result = await askFinance(trimmed);
      setResponse(result);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong."
      );
    } finally {
      setLoading(false);
    }
  }

  function handleOpenReport(report: SavedReport) {
    setSelectedReport(report);
    setActivePage("Data Explorer");
  }

  function handleDashboardSaved() {
    setSavedReportsRefreshKey((current) => current + 1);
  }

  function handleNavigation(page: string) {
    setActivePage(page);

    // Entering Data Explorer from the sidebar starts a new dashboard.
    // Opening a saved report uses handleOpenReport instead.
    if (page === "Data Explorer") {
      setSelectedReport(null);
    }

    if (page === "Saved Reports") {
      setSavedReportsRefreshKey((current) => current + 1);
    }
  }

  return (
    <div className="app-shell">
      <Sidebar
        activePage={activePage}
        onNavigate={handleNavigation}
      />

      <main className="main-panel">
        <header className="topbar">
          <div>
            <span className="eyebrow">VBI FINANCE INTELLIGENCE</span>
            <h1>{activePage}</h1>
          </div>

          <div className="connection-status">
            <span />
            BigQuery connected via API
          </div>
        </header>

        {activePage === "Data Explorer" ? (
          <DashboardWorkspace
            savedReport={selectedReport}
            onSaved={handleDashboardSaved}
          />
        ) : activePage === "Visualizations" ? (
          <VisualizationBuilder />
        ) : activePage === "Saved Reports" ? (
          <section className="saved-reports-page">
            {selectedReport && (
              <div className="saved-reports-notice">
                Selected report:{" "}
                <strong>{selectedReport.report_name}</strong>

                <button
                  type="button"
                  onClick={() => setSelectedReport(null)}
                >
                  Clear selection
                </button>
              </div>
            )}

            <SavedReports
              refreshKey={savedReportsRefreshKey}
              onOpenReport={handleOpenReport}
            />
          </section>
        ) : activePage === "Finance Assistant" ? (
          <section className="assistant-content">
            <div className="welcome-block">
              <div className="ai-mark">✦</div>

              <p className="eyebrow">
                FINANCE INTELLIGENCE
              </p>

              <h2>
                Your finance data.
                <br />
                <span style={{ color: "#E60000" }}>
                  Clearer decisions.
                </span>
              </h2>

              <p className="welcome-copy">
                Explore financial performance across Actuals,
                Budget and QRF. Ask questions about revenue,
                cost of sales, segments, regions and customers.
              </p>
            </div>

            {!response && !loading && (
              <div className="suggestion-area">
                <p className="section-label">
                  SUGGESTED FINANCIAL ANALYSIS
                </p>

                <div className="suggestion-grid">
                  {suggestions.map((item) => (
                    <button
                      key={item}
                      className="suggestion-card"
                      onClick={() => void submitQuestion(item)}
                    >
                      <span>{item}</span>
                      <b>↗</b>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="conversation-area">
              {question && (
                <div className="user-question">
                  <span>You</span>
                  <p>{question}</p>
                </div>
              )}

              {loading && (
                <div className="loading-state">
                  <span className="spinner" />
                  Analysing your finance question…
                </div>
              )}

              {error && (
                <div className="error-message">
                  <strong>Unable to complete the analysis</strong>
                  <p>{error}</p>
                </div>
              )}

              {response && (
                <FinanceResponseView response={response} />
              )}
            </div>

            <form
              className="composer"
              onSubmit={(event) => {
                event.preventDefault();
                void submitQuestion();
              }}
            >
              <textarea
                value={question}
                onChange={(event) => setQuestion(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void submitQuestion();
                  }
                }}
                placeholder="Ask a finance question..."
                rows={2}
                aria-label="Ask a finance question"
              />

              <div className="composer-footer">
                <span>
                  Powered by governed finance data
                </span>

                <button
                  type="submit"
                  disabled={!question.trim() || loading}
                >
                  {loading ? "Analysing..." : "Analyse"}
                  <span>↑</span>
                </button>
              </div>
            </form>

            <p className="disclaimer">
              Finance calculations are based on governed
              business logic and BigQuery data.
            </p>
          </section>
        ) : (
          <section className="placeholder-page">
            <div className="placeholder-icon">✦</div>
            <h2>{activePage}</h2>

            <p>
              This workspace will be available in a future phase.
            </p>

            <button
              className="secondary-button"
              onClick={() => setActivePage("Finance Assistant")}
            >
              Return to Finance Assistant
            </button>
          </section>
        )}
      </main>
    </div>
  );
}
