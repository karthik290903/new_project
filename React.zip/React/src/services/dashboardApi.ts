
const API_BASE_URL = "/api";

export interface DashboardCatalog {
  dimensions: {
    value: string;
    label: string;
  }[];
  measures: {
    value: string;
    label: string;
  }[];
  scenarios: {
    value: string;
    label: string;
  }[];
}

export interface DashboardChartRequest {
  chart_id: string;
  chart_type: "kpi" | "table" | "bar" | "line" | "donut" | "stacked";
  dimension: string;
  measure: string;
  scenario: "ACT" | "DB" | "QRF";
  filters?: Record<string, string | string[]>;
}

export interface DashboardChartData {
  chart_id: string;
  columns: string[];
  rows: Record<string, string | number | null>[];
  total_rows: number;
}

async function dashboardRequest<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Dashboard API error: ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export function getDashboardCatalog(): Promise<DashboardCatalog> {
  return dashboardRequest<DashboardCatalog>("/dashboard/catalog");
}

export function getDashboardChartData(
  request: DashboardChartRequest
): Promise<DashboardChartData> {
  return dashboardRequest<DashboardChartData>("/dashboard/chart-data", {
    method: "POST",
    body: JSON.stringify(request),
  });
}
