import type { FinanceResponse } from "../types/finance";
import type { VisualizationRequest, VisualizationResponse } from "../types/visualization";

// Leave empty when using the Vite development proxy.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

export async function askFinance(question: string): Promise<FinanceResponse> {
  const response = await fetch(`${API_BASE_URL}/api/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ question }),
  });

  const payload: unknown = await response.json().catch(() => null);

  if (!response.ok) {
    const detail =
      payload && typeof payload === "object" && "detail" in payload
        ? (payload as { detail?: unknown }).detail
        : undefined;
    throw new Error(typeof detail === "string" ? detail : `Request failed (${response.status})`);
  }

  return payload as FinanceResponse;
}


export async function generateVisualization(request: VisualizationRequest): Promise<VisualizationResponse> {
  const response = await fetch(`${API_BASE_URL}/api/visualizations`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(request),
  });
  const payload: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = payload && typeof payload === "object" && "detail" in payload
      ? (payload as { detail?: unknown }).detail : undefined;
    throw new Error(typeof detail === "string" ? detail : `Visualization request failed (${response.status})`);
  }
  return payload as VisualizationResponse;
}
