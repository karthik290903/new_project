
import { useEffect, useMemo, useState } from "react";

import {
  getDashboardCatalog,
  getDashboardChartData,
  type DashboardCatalog,
  type DashboardChartData,
} from "../services/dashboardApi";

import {
  saveReport,
  updateSavedReport,
  type SavedReport,
} from "../services/reportsApi";
type ChartType = "kpi" | "table" | "bar" | "line" | "donut" | "stacked";

interface SavedReportInput {
  report_id: string;
  report_name: string;
  definition?: {
    charts?: Array<{
      id?: string;
      chart_id?: string;
      title?: string;
      chart_type?: string;
      type?: string;
      dimension?: string;
      measure?: string;
      scenario?: string;
    }>;
    filters?: Record<string, string | string[]>;
  };
}

interface DashboardWorkspaceProps {
  savedReport?: SavedReportInput | null;
  onSaved?: () => void;
}

interface DashboardChart {
  id: string;
  title: string;
  type: ChartType;
  dimension: string;
  measure: string;
  scenario: string;
}

const chartLibrary: {
  type: ChartType;
  label: string;
  description: string;
  icon: string;
}[] = [
  { type: "kpi", label: "KPI Card", description: "Highlight a key financial measure", icon: "▣" },
  { type: "table", label: "Table", description: "Show detailed financial records", icon: "▤" },
  { type: "bar", label: "Bar Chart", description: "Compare financial categories", icon: "▥" },
  { type: "line", label: "Line Chart", description: "Track performance over time", icon: "⌁" },
  { type: "donut", label: "Donut Chart", description: "Show category contribution", icon: "◉" },
  { type: "stacked", label: "Stacked Bar", description: "Compare multiple series", icon: "▥" },
];

const fallbackCatalog: DashboardCatalog = {
  dimensions: [
    { value: "region", label: "Region" },
    { value: "segment", label: "Segment" },
    { value: "financial_period", label: "Financial Period" },
    { value: "country", label: "Country" },
    { value: "product", label: "Product" },
    { value: "customer_name", label: "Customer" },
    { value: "hyper_cat", label: "Hyper Category" },
  ],
  measures: [
    { value: "TOTAL_REVENUE", label: "Total Revenue" },
    { value: "SERVICE_REVENUE", label: "Service Revenue" },
    { value: "NON_SERVICE_REVENUE", label: "Non-Service Revenue" },
    { value: "COST_OF_SALES", label: "Cost of Sales" },
  ],
  scenarios: [
    { value: "ACT", label: "Actuals" },
    { value: "DB", label: "Budget" },
    { value: "QRF", label: "QRF Forecast" },
  ],
};

function createChart(type: ChartType): DashboardChart {
  const definition = chartLibrary.find((item) => item.type === type);

  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: definition?.label ?? "New Chart",
    type,
    dimension: "region",
    measure: "TOTAL_REVENUE",
    scenario: "ACT",
  };kend
  
}

function numericValue(value: unknown): number {
  if (value === null || value === undefined || value === "") return 0;

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatValue(value: number): string {
  return new Intl.NumberFormat("en-GB", {
    notation: "compact",
    maximumFractionDigits: 2,
  }).format(value);
}

function ChartPreview({
  chart,
  data,
  loading,
  error,
}: {
  chart: DashboardChart;
  data?: DashboardChartData;
  loading: boolean;
  error?: string;
}) {
  const rows = data?.rows ?? [];

  const points = rows.map((row) => ({
    label: String(row.dimension_value ?? "Unassigned"),
    value: numericValue(row.metric_value),
  }));

  const total = points.reduce((sum, point) => sum + point.value, 0);
  const maxValue = Math.max(
    ...points.map((point) => Math.abs(point.value)),
    0
  );

  if (loading) {
    return <div className="vf-data-state">Loading BigQuery data…</div>;
  }

  if (error) {
    return (
      <div className="vf-data-error">
        Unable to load chart data: {error}
      </div>
    );
  }

  if (!points.length) {
    return (
      <div className="vf-data-state">
        No data available for this selection.
      </div>
    );
  }

  if (chart.type === "kpi") {
    return (
      <div className="vf-kpi-preview">
        <span className="vf-small-label">
          {chart.measure.replace("_", " ")}
        </span>

        <strong>{formatValue(total)}</strong>

        <span className="vf-data-caption">
          {data?.total_rows ?? points.length} grouped records · {chart.scenario}
        </span>

        <div className="vf-mini-bars">
          {points.slice(0, 12).map((point, index) => (
            <i
              key={`${point.label}-${index}`}
              style={{
                height: `${Math.max(
                  5,
                  maxValue ? (Math.abs(point.value) / maxValue) * 100 : 5
                )}%`,
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (chart.type === "table") {
    return (
      <div className="vf-table">
        <div className="vf-table-row vf-table-head">
          <span>{chart.dimension.replace("_", " ")}</span>
          <span>{chart.measure.replace("_", " ")}</span>
        </div>

        {points.map((point, index) => (
          <div
            className="vf-table-row"
            key={`${point.label}-${index}`}
          >
            <span>{point.label}</span>
            <strong>{formatValue(point.value)}</strong>
          </div>
        ))}
      </div>
    );
  }

  if (chart.type === "donut") {
    let running = 0;

    const palette = [
      "#E60000",
      "#ef7777",
      "#a94b4b",
      "#bcbcbc",
      "#777777",
      "#f3aaaa",
    ];

    const absoluteTotal = points.reduce(
      (sum, point) => sum + Math.abs(point.value),
      0
    );

    const segments = points.map((point, index) => {
      const start = running;

      running += absoluteTotal
        ? (Math.abs(point.value) / absoluteTotal) * 100
        : 0;

      return `${palette[index % palette.length]} ${start}% ${running}%`;
    });

    return (
      <div className="vf-donut-layout">
        <div
          className="vf-donut"
          style={{
            background: `conic-gradient(${segments.join(", ")})`,
          }}
        >
          <div className="vf-donut-hole">
            <strong>{formatValue(total)}</strong>
            <span>Total</span>
          </div>
        </div>

        <div className="vf-legend">
          {points.slice(0, 7).map((point, index) => (
            <div key={`${point.label}-${index}`}>
              <i
                className="vf-dot"
                style={{
                  background: palette[index % palette.length],
                }}
              />

              <span>{point.label}</span>

              <strong>
                {absoluteTotal
                  ? `${(
                      (Math.abs(point.value) / absoluteTotal) *
                      100
                    ).toFixed(1)}%`
                  : "0%"}
              </strong>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (chart.type === "line") {
    const width = 520;
    const height = 150;
    const max = maxValue || 1;
    const min = Math.min(
      ...points.map((point) => point.value),
      0
    );
    const range = max - min || 1;

    const coordinates = points.map((point, index) => {
      const x =
        points.length === 1
          ? width / 2
          : (index / (points.length - 1)) * width;

      const y =
        height -
        ((point.value - min) / range) * (height - 20) -
        10;

      return `${x},${y}`;
    });

    return (
      <div className="vf-line-preview">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="none"
          role="img"
          aria-label={`${chart.title} line chart`}
        >
          {[25, 60, 95, 130].map((y) => (
            <line
              key={y}
              x1="0"
              y1={y}
              x2={width}
              y2={y}
              stroke="#dedede"
              strokeDasharray="4 5"
            />
          ))}

          <polyline
            points={coordinates.join(" ")}
            fill="none"
            stroke="#E60000"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>

        <div className="vf-axis-labels">
          {points
            .filter(
              (_, index) =>
                index % Math.max(1, Math.ceil(points.length / 6)) === 0
            )
            .map((point, index) => (
              <span key={`${point.label}-${index}`}>
                {point.label}
              </span>
            ))}
        </div>
      </div>
    );
  }

  return (
    <div className="vf-bar-preview">
      {points.map((point, index) => (
        <div
          className="vf-bar-row"
          key={`${point.label}-${index}`}
        >
          <span title={point.label}>{point.label}</span>

          <div className="vf-bar-track">
            <i
              style={{
                width: `${
                  maxValue
                    ? (Math.abs(point.value) / maxValue) * 100
                    : 0
                }%`,
              }}
            />
          </div>

          <strong>{formatValue(point.value)}</strong>
        </div>
      ))}
    </div>
  );
}

export default function DashboardWorkspace({
  savedReport = null,
  onSaved,
}: DashboardWorkspaceProps) {
  const [dashboardName, setDashboardName] = useState(
    "Finance Performance Dashboard"
  );

  const [restoredReportId, setRestoredReportId] = useState<string | null>(
    null
  );

  const [restoredFilters, setRestoredFilters] = useState<
    Record<string, string | string[]>
  >({});

  const [saving, setSaving] = useState(false);

  const [charts, setCharts] = useState<DashboardChart[]>([
    { ...createChart("kpi"), title: "Total Revenue" },
    { ...createChart("bar"), title: "Revenue by Region" },
    { ...createChart("line"), title: "Revenue Trend" },
  ]);

  const [selectedChartId, setSelectedChartId] = useState<string | null>(null);
  const [showLibrary, setShowLibrary] = useState(true);
  const [showSettings, setShowSettings] = useState(true);
  const [draggedChartId, setDraggedChartId] = useState<string | null>(null);

  const [catalog, setCatalog] = useState<DashboardCatalog>(fallbackCatalog);
  const [catalogError, setCatalogError] = useState("");

  const [chartData, setChartData] = useState<
    Record<string, DashboardChartData>
  >({});

  const [chartLoading, setChartLoading] = useState<
    Record<string, boolean>
  >({});

  const [chartErrors, setChartErrors] = useState<
    Record<string, string>
  >({});

  // Restore the selected saved report.
  // Updating charts triggers the existing BigQuery chart-data effect.
  useEffect(() => {
    if (!savedReport) return;

    const savedCharts = savedReport.definition?.charts;

    if (!Array.isArray(savedCharts)) return;

    const restoredCharts: DashboardChart[] = savedCharts.map(
      (item, index) => {
        const rawType = item.chart_type ?? item.type ?? "bar";

        const validType: ChartType =
          chartLibrary.some((chartType) => chartType.type === rawType)
            ? (rawType as ChartType)
            : "bar";

        return {
          id:
            item.id ??
            item.chart_id ??
            `restored-${savedReport.report_id}-${index}`,

          title:
            item.title ??
            chartLibrary.find((entry) => entry.type === validType)?.label ??
            "Saved chart",

          type: validType,
          dimension: item.dimension ?? "region",
          measure: item.measure ?? "TOTAL_REVENUE",
          scenario: item.scenario ?? "ACT",
        };
      }
    );

    setDashboardName(
      savedReport.report_name || "Saved Finance Dashboard"
    );

    setCharts(restoredCharts);
    setSelectedChartId(restoredCharts[0]?.id ?? null);

    setRestoredFilters(savedReport.definition?.filters ?? {});
    setRestoredReportId(savedReport.report_id);

    setChartData({});
    setChartErrors({});
    setChartLoading({});
  }, [savedReport]);

  const selectedChart = useMemo(
    () => charts.find((chart) => chart.id === selectedChartId) ?? null,
    [charts, selectedChartId]
  );

  // Load dashboard catalog.
  useEffect(() => {
    let cancelled = false;

    getDashboardCatalog()
      .then((result) => {
        if (!cancelled) {
          setCatalog(result);
          setCatalogError("");
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          setCatalogError(
            error instanceof Error
              ? error.message
              : "Catalog request failed"
          );
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // Fetch fresh BigQuery data for every chart.
  useEffect(() => {
    let cancelled = false;

    charts.forEach((chart) => {
      setChartLoading((current) => ({
        ...current,
        [chart.id]: true,
      }));

      setChartErrors((current) => ({
        ...current,
        [chart.id]: "",
      }));

      getDashboardChartData({
        chart_id: chart.id,
        chart_type: chart.type,
        dimension: chart.dimension,
        measure: chart.measure,
        scenario: chart.scenario as "ACT" | "DB" | "QRF",
      })
        .then((result) => {
          if (!cancelled) {
            setChartData((current) => ({
              ...current,
              [chart.id]: result,
            }));
          }
        })
        .catch((error: unknown) => {
          if (!cancelled) {
            setChartErrors((current) => ({
              ...current,
              [chart.id]:
                error instanceof Error
                  ? error.message
                  : "Chart query failed",
            }));
          }
        })
        .finally(() => {
          if (!cancelled) {
            setChartLoading((current) => ({
              ...current,
              [chart.id]: false,
            }));
          }
        });
    });

    return () => {
      cancelled = true;
    };
  }, [charts]);

  function addChart(type: ChartType) {
    const chart = createChart(type);

    setCharts((current) => [...current, chart]);
    setSelectedChartId(chart.id);
  }

  function updateSelected(
    field: keyof DashboardChart,
    value: string
  ) {
    if (!selectedChartId) return;

    setCharts((current) =>
      current.map((chart) =>
        chart.id === selectedChartId
          ? { ...chart, [field]: value }
          : chart
      )
    );
  }

  function removeSelected() {
    if (!selectedChartId) return;

    const removedId = selectedChartId;

    setCharts((current) =>
      current.filter((chart) => chart.id !== removedId)
    );

    setChartData((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setChartLoading((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setChartErrors((current) => {
      const next = { ...current };
      delete next[removedId];
      return next;
    });

    setSelectedChartId(null);
  }

  function moveChart(targetId: string) {
    if (!draggedChartId || draggedChartId === targetId) return;

    setCharts((current) => {
      const updated = [...current];

      const fromIndex = updated.findIndex(
        (chart) => chart.id === draggedChartId
      );

      const toIndex = updated.findIndex(
        (chart) => chart.id === targetId
      );

      if (fromIndex < 0 || toIndex < 0) return current;

      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, moved);

      return updated;
    });

    setDraggedChartId(null);
  }

  async function saveDashboard() {
    const trimmedName = dashboardName.trim();

    if (!trimmedName) {
      window.alert("Please enter a dashboard name.");
      return;
    }

    if (charts.length === 0) {
      window.alert("Please add at least one chart before saving.");
      return;
    }

    const definition = {
      charts: charts.map((chart) => ({
        chart_id: chart.id,
        title: chart.title,
        chart_type: chart.type,
        dimension: chart.dimension,
        measure: chart.measure,
        scenario: chart.scenario as "ACT" | "DB" | "QRF",
      })),
      filters: restoredFilters,
    };

    try {
      setSaving(true);

      if (restoredReportId) {
        await updateSavedReport(restoredReportId, {
          report_name: trimmedName,
          description:
            "Finance dashboard created using Dashboard Studio",
          definition,
        });

        window.alert("Dashboard updated successfully!");
      } else {
        const result = await saveReport({
          report_name: trimmedName,
          description:
            "Finance dashboard created using Dashboard Studio",
          definition,
        });

        setRestoredReportId(result.report_id);

        window.alert("Dashboard saved successfully!");
      }

      // Refresh the Saved Reports list after a successful save or update.
      onSaved?.();
    } catch (error) {
      console.error("Dashboard save error:", error);

      window.alert(
        error instanceof Error
          ? `Unable to save dashboard: ${error.message}`
          : "Unable to save dashboard."
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="vf-dashboard">

<style>{`
  .vf-dashboard {
    height: calc(100dvh - 82px);
    min-height: 480px;
    display: flex;
    flex-direction: column;
    background: #f4f4f4;
    color: #252525;
    overflow: hidden;
    font-family: inherit;
  }

  .vf-toolbar {
    min-height: 62px;
    padding: 0 22px;
    background: #fff;
    border-bottom: 1px solid #dedede;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-shrink: 0;
  }

  .vf-toolbar-left,
  .vf-toolbar-right {
    display: flex;
    align-items: center;
    gap: 9px;
  }

  .vf-toolbar h2 {
    font-size: 16px;
    margin: 0 12px 0 0;
    font-weight: 700;
  }

  .vf-button {
    border: 1px solid #d6d6d6;
    background: #fff;
    color: #333;
    border-radius: 4px;
    padding: 9px 12px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
  }

  .vf-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .vf-button:hover {
    border-color: #E60000;
    color: #E60000;
  }

  .vf-button.primary {
    background: #E60000;
    border-color: #E60000;
    color: #fff;
  }

  .vf-button.primary:hover {
    background: #c90000;
  }

  .vf-layout {
    display: flex;
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }

  .vf-panel {
    width: 220px;
    flex-shrink: 0;
    overflow-y: auto;
    padding: 17px 14px;
    background: #fff;
    border-right: 1px solid #dedede;
  }

  .vf-settings {
    width: 245px;
    border-right: 0;
    border-left: 1px solid #dedede;
  }

  .vf-panel-heading {
    background: #E60000;
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    padding: 10px;
    margin: 0 0 13px;
    letter-spacing: .2px;
  }

  .vf-library-item {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    padding: 11px 9px;
    margin-bottom: 7px;
    background: #fff;
    border: 1px solid #e5e5e5;
    border-radius: 3px;
    text-align: left;
    color: #292929;
    cursor: pointer;
  }

  .vf-library-item:hover {
    border-color: #E60000;
    background: #fffafa;
  }

  .vf-library-icon {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    background: #fce9e9;
    color: #E60000;
    font-size: 16px;
    flex-shrink: 0;
  }

  .vf-library-item strong {
    display: block;
    font-size: 10px;
    margin-bottom: 3px;
  }

  .vf-library-item small {
    display: block;
    color: #777;
    font-size: 9px;
  }

  .vf-canvas {
    flex: 1;
    min-width: 0;
    padding: 22px;
    overflow: auto;
    background: #f4f4f4;
  }

  .vf-section-heading {
    background: #E60000;
    color: #fff;
    padding: 12px 15px;
    margin-bottom: 17px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .vf-section-heading input {
    width: min(500px, 75%);
    background: transparent;
    color: white;
    border: 0;
    outline: none;
    font-size: 15px;
    font-weight: 700;
  }

  .vf-section-heading input::placeholder {
    color: #fff;
  }

  .vf-count {
    font-size: 10px;
    white-space: nowrap;
  }

  .vf-chart-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 15px;
    align-items: start;
  }

  .vf-chart-card {
    min-width: 0;
    min-height: 215px;
    overflow: auto;
    resize: both;
    padding: 15px;
    background: #fff;
    border: 1px solid #dedede;
    border-radius: 3px;
    cursor: grab;
    position: relative;
  }

  .vf-chart-card:active {
    cursor: grabbing;
  }

  .vf-chart-card.selected {
    border: 2px solid #E60000;
    padding: 14px;
  }

  .vf-chart-card.dragging {
    opacity: .45;
  }

  .vf-chart-card:first-child {
    grid-column: span 2;
    min-height: 165px;
  }

  .vf-chart-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #e9e9e9;
  }

  .vf-chart-header strong {
    font-size: 12px;
    color: #333;
  }

  .vf-chart-header span {
    font-size: 9px;
    color: #777;
    background: #f3f3f3;
    padding: 5px 7px;
  }

  .vf-kpi-preview {
    min-height: 95px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    position: relative;
  }

  .vf-small-label {
    color: #777;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: .6px;
  }

  .vf-kpi-preview > strong {
    color: #A40000;
    font-size: 30px;
    margin: 7px 0 3px;
  }

  .vf-data-caption {
    color: #777;
    font-size: 10px;
  }

  .vf-mini-bars {
    position: absolute;
    right: 8px;
    bottom: 0;
    width: 35%;
    height: 65px;
    display: flex;
    align-items: flex-end;
    gap: 5px;
  }

  .vf-mini-bars i {
    flex: 1;
    background: #E60000;
    opacity: .8;
  }

  .vf-bar-preview {
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding: 8px 0;
  }

  .vf-bar-row {
    display: grid;
    grid-template-columns: minmax(55px, 90px) minmax(30px, 1fr) 55px;
    align-items: center;
    gap: 9px;
    color: #555;
    font-size: 9px;
  }

  .vf-bar-row > span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .vf-bar-row strong {
    text-align: right;
    color: #333;
  }

  .vf-bar-track {
    height: 9px;
    background: #ededed;
  }

  .vf-bar-track i {
    display: block;
    height: 100%;
    background: #E60000;
  }

  .vf-line-preview {
    height: 145px;
  }

  .vf-line-preview svg {
    height: 120px;
    width: 100%;
  }

  .vf-axis-labels {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    font-size: 8px;
    color: #777;
    overflow: hidden;
  }

  .vf-axis-labels span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .vf-donut-layout {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 25px;
  }

  .vf-donut {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    flex-shrink: 0;
  }

  .vf-donut-hole {
    width: 76px;
    height: 76px;
    background: #fff;
    border-radius: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .vf-donut-hole strong {
    font-size: 13px;
    color: #333;
  }

  .vf-donut-hole span {
    font-size: 9px;
    color: #888;
  }

  .vf-legend {
    display: flex;
    flex-direction: column;
    gap: 10px;
    min-width: 100px;
    max-height: 145px;
    overflow: auto;
  }

  .vf-legend > div {
    display: grid;
    grid-template-columns: 8px 1fr auto;
    align-items: center;
    gap: 6px;
    font-size: 9px;
    color: #555;
  }

  .vf-legend strong {
    color: #333;
  }

  .vf-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
  }

  .vf-table {
    font-size: 10px;
    max-height: 260px;
    overflow: auto;
  }

  .vf-table-row {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 12px;
    padding: 10px 5px;
    border-bottom: 1px solid #ededed;
    color: #555;
  }

  .vf-table-row strong {
    color: #333;
  }

  .vf-table-head {
    color: #777;
    font-weight: 700;
    background: #f7f7f7;
  }

  .vf-field {
    margin-bottom: 15px;
  }

  .vf-field label {
    display: block;
    margin-bottom: 7px;
    color: #555;
    font-size: 10px;
    font-weight: 600;
  }

  .vf-field input,
  .vf-field select {
    width: 100%;
    box-sizing: border-box;
    padding: 9px;
    border: 1px solid #d6d6d6;
    border-radius: 3px;
    background: #fff;
    color: #333;
    font-size: 10px;
    outline: none;
  }

  .vf-field input:focus,
  .vf-field select:focus {
    border-color: #E60000;
  }

  .vf-delete {
    width: 100%;
    padding: 9px;
    border: 1px solid #E60000;
    background: #fff;
    color: #E60000;
    font-size: 10px;
    cursor: pointer;
  }

  .vf-delete:hover {
    background: #fff1f1;
  }

  .vf-empty {
    min-height: 260px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: #fff;
    border: 1px dashed #ccc;
  }

  .vf-empty strong {
    font-size: 14px;
    color: #333;
    margin-bottom: 7px;
  }

  .vf-empty p,
  .vf-hint {
    font-size: 10px;
    color: #777;
    line-height: 1.6;
  }

  .vf-hint {
    margin-top: 14px;
  }

  .vf-selection-hint {
    padding: 12px;
    border: 1px dashed #ccc;
    color: #777;
    font-size: 10px;
    line-height: 1.7;
  }

  .vf-data-state,
  .vf-data-error {
    padding: 24px 12px;
    text-align: center;
    font-size: 11px;
    color: #777;
    background: #fafafa;
    border: 1px dashed #ddd;
  }

  .vf-data-error {
    color: #a40000;
    background: #fff8f8;
    border-color: #e8baba;
    overflow-wrap: anywhere;
  }

  .vf-catalog-warning {
    margin: 0 0 12px;
    padding: 9px;
    background: #fff8e8;
    color: #795b1b;
    font-size: 10px;
  }

  @media (max-width: 950px) {
    .vf-panel {
      width: 185px;
    }

    .vf-settings {
      width: 210px;
    }
  }

  @media (max-width: 680px) {
    .vf-panel {
      position: absolute;
      z-index: 10;
      top: 145px;
      bottom: 0;
      box-shadow: 0 5px 20px #0002;
    }

    .vf-settings {
      right: 0;
    }

    .vf-chart-grid {
      grid-template-columns: 1fr;
    }

    .vf-chart-card:first-child {
      grid-column: span 1;
    }

    .vf-toolbar {
      padding: 0 10px;
    }

    .vf-toolbar h2 {
      display: none;
    }

    .vf-canvas {
      padding: 12px;
    }
  }
`}</style>

      <header className="vf-toolbar">
        <div className="vf-toolbar-left">
          <h2>Dashboard Studio</h2>

          <button
            className="vf-button"
            onClick={() => setShowLibrary((value) => !value)}
          >
            {showLibrary ? "← Hide charts" : "☰ Chart library"}
          </button>

          <button
            className="vf-button"
            onClick={() => setShowSettings((value) => !value)}
          >
            {showSettings ? "Hide settings →" : "⚙ Configure"}
          </button>
        </div>

        <div className="vf-toolbar-right">
          <button
            className="vf-button primary"
            onClick={() => void saveDashboard()}
            disabled={saving}
          >
            {saving
              ? "Saving..."
              : restoredReportId
                ? "Update dashboard"
                : "Save dashboard"}
          </button>
        </div>
      </header>

      <div className="vf-layout">
        {showLibrary && (
          <aside className="vf-panel">
            <h3 className="vf-panel-heading">Chart library</h3>

            {chartLibrary.map((item) => (
              <button
                className="vf-library-item"
                key={item.type}
                onClick={() => addChart(item.type)}
              >
                <span className="vf-library-icon">{item.icon}</span>

                <span>
                  <strong>{item.label}</strong>
                  <small>{item.description}</small>
                </span>
              </button>
            ))}

            <p className="vf-hint">
              Select a visual to add it to your dashboard.
            </p>
          </aside>
        )}

        <main className="vf-canvas">
          <div className="vf-section-heading">
            <input
              aria-label="Dashboard name"
              value={dashboardName}
              onChange={(event) => setDashboardName(event.target.value)}
            />

            <span className="vf-count">
              {charts.length} visuals
              {restoredReportId ? " · Restored report" : ""}
              {Object.keys(restoredFilters).length > 0
                ? " · Saved filters retained"
                : ""}
            </span>
          </div>

          {catalogError && (
            <div className="vf-catalog-warning">
              Could not refresh the field catalog. Showing the default field
              list. {catalogError}
            </div>
          )}

          {charts.length === 0 ? (
            <div className="vf-empty">
              <strong>Your dashboard is ready to build</strong>

              <p>
                Add a KPI, table or chart from the chart library.
              </p>

              <button
                className="vf-button primary"
                onClick={() => addChart("kpi")}
              >
                Add your first KPI
              </button>
            </div>
          ) : (
            <div className="vf-chart-grid">
              {charts.map((chart) => (
                <article
                  key={chart.id}
                  draggable
                  onDragStart={() => setDraggedChartId(chart.id)}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={() => moveChart(chart.id)}
                  onDragEnd={() => setDraggedChartId(null)}
                  onClick={() => setSelectedChartId(chart.id)}
                  className={`vf-chart-card ${
                    selectedChartId === chart.id ? "selected" : ""
                  } ${draggedChartId === chart.id ? "dragging" : ""}`}
                >
                  <div className="vf-chart-header">
                    <strong>{chart.title}</strong>

                    <span>
                      {chartLibrary.find(
                        (item) => item.type === chart.type
                      )?.label}
                      {" · Drag to move"}
                    </span>
                  </div>

                  <ChartPreview
                    chart={chart}
                    data={chartData[chart.id]}
                    loading={!!chartLoading[chart.id]}
                    error={chartErrors[chart.id]}
                  />
                </article>
              ))}
            </div>
          )}

          <p className="vf-hint">
            Select a chart to configure it. Drag charts to rearrange them and
            use the resize handle at the bottom-right of a chart.
          </p>
        </main>

        {showSettings && (
          <aside className="vf-panel vf-settings">
            <h3 className="vf-panel-heading">Chart configuration</h3>

            {!selectedChart ? (
              <div className="vf-selection-hint">
                Select a chart on the canvas to edit its title, dimension,
                measure and scenario.
              </div>
            ) : (
              <>
                <div className="vf-field">
                  <label>Chart title</label>

                  <input
                    value={selectedChart.title}
                    onChange={(event) =>
                      updateSelected("title", event.target.value)
                    }
                  />
                </div>

                <div className="vf-field">
                  <label>Chart type</label>

                  <select
                    value={selectedChart.type}
                    onChange={(event) =>
                      updateSelected("type", event.target.value)
                    }
                  >
                    {chartLibrary.map((item) => (
                      <option key={item.type} value={item.type}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label>Dimension</label>

                  <select
                    value={selectedChart.dimension}
                    onChange={(event) =>
                      updateSelected("dimension", event.target.value)
                    }
                  >
                    {catalog.dimensions.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label>Measure</label>

                  <select
                    value={selectedChart.measure}
                    onChange={(event) =>
                      updateSelected("measure", event.target.value)
                    }
                  >
                    {catalog.measures.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="vf-field">
                  <label>Scenario</label>

                  <select
                    value={selectedChart.scenario}
                    onChange={(event) =>
                      updateSelected("scenario", event.target.value)
                    }
                  >
                    {catalog.scenarios.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  className="vf-delete"
                  onClick={removeSelected}
                >
                  Remove chart
                </button>
              </>
            )}
          </aside>
        )}
      </div>
    </section>
  );
}
